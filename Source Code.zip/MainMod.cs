﻿using ExpansionPack;
using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using MelonLoader;
using System;
using UnityEngine;
using static Il2CppSystem.Array;

[assembly: MelonInfo(typeof(MainMod), "Wingidon's Expansion Pack", "1.0", "Wingidon")]
[assembly: MelonGame("UmiArt", "Demon Bluff")]

namespace ExpansionPack;
public class MainMod : MelonMod
{
    public override void OnInitializeMelon()
    {
        ClassInjector.RegisterTypeInIl2Cpp<w_Prince>();
    }
    public override void OnLateInitializeMelon()
    {
        CharacterData w_prince = new CharacterData();
        w_prince.role = new w_Prince();
        w_prince.name = "Prince";
        w_prince.description = "Learn that exactly 1 of 2 characters is Disguised.";
        w_prince.flavorText = "\"Secretly wishes that his mother was more trusting.\"";
        w_prince.hints = "";
        w_prince.ifLies = "Both characters in my info are Honest.";
        w_prince.picking = false;
        w_prince.startingAlignment = EAlignment.Good;
        w_prince.type = ECharacterType.Villager;
        w_prince.bluffable = true;
        w_prince.characterId = "Prince_WING";
        w_prince.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_prince.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_prince.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_prince.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_forager = new CharacterData();
        w_forager.role = new w_Forager();
        w_forager.name = "Forager";
        w_forager.description = "Pick 1 character:\nLearn if they are a Villager.";
        w_forager.flavorText = "\"Her instructions are clear, it's just that her assistants don't follow them.\"";
        w_forager.hints = "";
        w_forager.ifLies = "";
        w_forager.picking = true;
        w_forager.startingAlignment = EAlignment.Good;
        w_forager.type = ECharacterType.Villager;
        w_forager.abilityUsage = EAbilityUsage.ResetAfterNight;
        w_forager.bluffable = true;
        w_forager.characterId = "Forager_WING";
        w_forager.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_forager.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_forager.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_forager.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_politician = new CharacterData();
        //w_politician.role = new w_Politician();
        //w_politician.name = "Politician";
        //w_politician.description = "<b>Game Start:</b>\nI am Corrupted.\n\nI Register as Lying.\nLearn random false info.";
        //w_politician.flavorText = "\"He just showed up one day and started bossing people around.\"";
        //w_politician.hints = "";
        //w_politician.ifLies = "My info is true instead.\nI still Register as Lying.";
        //w_politician.picking = false;
        //w_politician.startingAlignment = EAlignment.Good;
        //w_politician.type = ECharacterType.Villager;
        //w_politician.bluffable = true;
        //w_politician.characterId = "Politician_WING";
        //w_politician.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_politician.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_politician.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_politician.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_lunatic = new CharacterData();
        w_lunatic.role = new w_Lunatic();
        w_lunatic.name = "Lunatic";
        w_lunatic.description = "I Disguise.\nI might be Corrupted.";
        w_lunatic.flavorText = "\"Constantly attempts to search everyone's shadows for the truth.\nMight have taken the Poet's writings a bit too literally.\"";
        w_lunatic.hints = "I only Lie if I am Corrupted.\n\nI have a 50% chance to be Corrupted.\n\nTake 2 less damage when you Execute me.";
        w_lunatic.ifLies = "";
        w_lunatic.picking = false;
        w_lunatic.startingAlignment = EAlignment.Good;
        w_lunatic.type = ECharacterType.Outcast;
        w_lunatic.bluffable = false;
        w_lunatic.characterId = "Lunatic_WING";
        w_lunatic.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_lunatic.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_lunatic.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_lunatic.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_turncoat = new CharacterData();
        w_turncoat.role = new w_Turncoat();
        w_turncoat.name = "Turncoat";
        w_turncoat.description = "I Disguise.";
        w_turncoat.flavorText = "\"Hurt me with the truth, but don't comfort me with a lie.\"";
        w_turncoat.hints = "I never Lie, even if for some reason I would.";
        w_turncoat.ifLies = "";
        w_turncoat.picking = false;
        w_turncoat.startingAlignment = EAlignment.Evil;
        w_turncoat.type = ECharacterType.Minion;
        w_turncoat.bluffable = false;
        w_turncoat.characterId = "Turncoat_WING";
        w_turncoat.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_turncoat.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_turncoat.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_turncoat.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_legion = new CharacterData();
        w_legion.role = new w_Legion();
        w_legion.name = "Legionary";
        w_legion.description = "<b>Game Start:</b>\nMost characters are Minions.\n\nI Lie and Disguise.";
        w_legion.flavorText = "\"They are the chill wind on a winter's day. They are the shadow in the moonless night. They are the poison in your tea and the whisper in your ear. They are everywhere.\"";
        w_legion.hints = "Only works in Endless. Functions as a weak Demon in non-Endless.";
        w_legion.ifLies = "";
        w_legion.picking = false;
        w_legion.startingAlignment = EAlignment.Evil;
        w_legion.type = ECharacterType.Demon;
        w_legion.bluffable = false;
        w_legion.characterId = "Legion_WING";
        w_legion.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_legion.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_legion.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_legion.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_spy = new CharacterData();
        //w_spy.role = new w_Spy();
        //w_spy.name = "Spy";
        //w_spy.description = "Learn an Evil role that has not been Revealed yet, or that all have been.";
        //w_spy.flavorText = "\"Thinks he's extremely stealthy. He's not.\"";
        //w_spy.hints = "";
        //w_spy.ifLies = "";
        //w_spy.picking = false;
        //w_spy.startingAlignment = EAlignment.Good;
        //w_spy.type = ECharacterType.Villager;
        //w_spy.bluffable = true;
        //w_spy.characterId = "Spy_WING";
        //w_spy.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_spy.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_spy.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_spy.color = new Color(1f, 0.935f, 0.7302f);




        CustomScriptData legionScriptData = new CustomScriptData();
        legionScriptData.name = "Legion_1";
        ScriptInfo legionScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> legionList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        legionList.Add(w_legion);
        legionScript.mustInclude = legionList;
        legionScript.startingDemons = legionList;
        legionScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        legionScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        legionScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount legionCounter1 = new CharactersCount(5, 1, 1, 1, 2);
        legionCounter1.dOuts = legionCounter1.outs + 1;
        CharactersCount legionCounter2 = new CharactersCount(6, 1, 1, 1, 3);
        legionCounter2.dOuts = legionCounter2.outs + 1;
        CharactersCount legionCounter3 = new CharactersCount(7, 2, 1, 1, 3);
        legionCounter3.dOuts = legionCounter3.outs + 1;
        CharactersCount legionCounter4 = new CharactersCount(8, 2, 1, 1, 4);
        legionCounter4.dOuts = legionCounter4.outs + 1;
        CharactersCount legionCounter5 = new CharactersCount(9, 2, 1, 1, 5);
        legionCounter4.dOuts = legionCounter5.outs + 1;
        CharactersCount legionCounter6 = new CharactersCount(10, 2, 1, 1, 6);
        legionCounter4.dOuts = legionCounter6.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> legionCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        legionCounterList.Add(legionCounter1);
        legionCounterList.Add(legionCounter2);
        legionCounterList.Add(legionCounter3);
        legionCounterList.Add(legionCounter4);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter6);
        legionScript.characterCounts = legionCounterList;
        legionScriptData.scriptInfo = legionScript;


        CustomScriptData legionScriptData2 = new CustomScriptData();
        legionScriptData.name = "Legion_2";
        legionScriptData2.scriptInfo = legionScript;




        AscensionsData advancedAscension = ProjectContext.Instance.gameData.advancedAscension;
        Il2CppReferenceArray<CharacterData> advancedAscensionDemons = new Il2CppReferenceArray<CharacterData>(advancedAscension.demons.Length + 1);
        advancedAscensionDemons = advancedAscension.demons;
        advancedAscensionDemons[advancedAscensionDemons.Length - 1] = w_legion;
        advancedAscension.demons = advancedAscensionDemons;
        Il2CppReferenceArray<CharacterData> advancedAscensionStartingDemons = new Il2CppReferenceArray<CharacterData>(advancedAscension.startingDemons.Length + 1);
        advancedAscensionStartingDemons = advancedAscension.startingDemons;
        advancedAscensionStartingDemons[advancedAscensionStartingDemons.Length - 1] = w_legion;
        advancedAscension.startingDemons = advancedAscensionStartingDemons;
        Il2CppReferenceArray<CustomScriptData> advancedAscensionScriptsData = new Il2CppReferenceArray<CustomScriptData>(advancedAscension.possibleScriptsData.Length + 2);
        advancedAscensionScriptsData = advancedAscension.possibleScriptsData;
        advancedAscensionScriptsData[advancedAscensionScriptsData.Length - 2] = legionScriptData;
        advancedAscensionScriptsData[advancedAscensionScriptsData.Length - 1] = legionScriptData2;
        advancedAscension.possibleScriptsData = advancedAscensionScriptsData;
        foreach (CustomScriptData scriptData in advancedAscension.possibleScriptsData)
        {
            ScriptInfo script = scriptData.scriptInfo;
            addRole(script.startingTownsfolks, w_prince);
            addRole(script.startingTownsfolks, w_forager);
            addRole(script.startingOutsiders, w_lunatic);
            addRole(script.startingMinions, w_turncoat);
            addRole(script.startingDemons, w_legion);
        }
    }
    public void addRole(Il2CppSystem.Collections.Generic.List<CharacterData> list, CharacterData data)
    {
        if (list.Contains(data))
        {
            return;
        }
        list.Add(data);
    }
    public CharacterData[] allDatas = Array.Empty<CharacterData>();
    public override void OnUpdate()
    {
        if (allDatas.Length == 0)
        {
            var loadedCharList = Resources.FindObjectsOfTypeAll(Il2CppType.Of<CharacterData>());
            if (loadedCharList != null)
            {
                allDatas = new CharacterData[loadedCharList.Length];
                for (int i = 0; i < loadedCharList.Length; i++)
                {
                    allDatas[i] = loadedCharList[i]!.Cast<CharacterData>();
                }
            }
        }
    }
    public CharacterData[] insertAfterAct(string previous, CharacterData data)
    {
        CharacterData[] actList = Characters.Instance.startGameActOrder;
        int actSize = actList.Length;
        CharacterData[] newActList = new CharacterData[actSize + 1];
        bool inserted = false;
        for (int i = 0; i < actSize; i++)
        {
            if (inserted)
            {
                newActList[i + 1] = actList[i];
            }
            else
            {
                newActList[i] = actList[i];
                if (actList[i].name == previous)
                {
                    newActList[i + 1] = data;
                    inserted = true;
                }
            }
        }
        if (!inserted)
        {
            LoggerInstance.Msg("");
        }
        return newActList;
    }
}