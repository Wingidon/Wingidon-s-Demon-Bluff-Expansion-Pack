﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Politician : Role
{
    public override string Description
    => "Become Corrupted and Learn random false info";


    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        Debug.Log("Politician acting...");
        if (trigger == ETriggerPhase.Start)
        {
            Debug.Log("Politician: Game Start act triggered, adding status effects.");
            charRef.statuses.AddStatus(ECharacterStatus.Corrupted, charRef);
            charRef.statuses.AddStatus(ECharacterStatus.HealthyBluff, charRef);
        }
        if (trigger == ETriggerPhase.Day)
        {
            Debug.Log("Politician: Day act triggered, getting info.");
            this.onActed.Invoke(this.GetInfo(charRef));
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        Debug.Log("Fake Politician acting...");
        if (trigger == ETriggerPhase.Day)
        {
            Debug.Log("Fake Politician: Day act triggered, getting info.");
            this.onActed.Invoke(this.GetBluffInfo(charRef));
        }
    }
    public override ActedInfo GetInfo(Character charRef)
    {
        Role role = poliInfoRoles[UnityEngine.Random.Range(0, poliInfoRoles.Count)];
        Debug.Log($"{charRef.id}, ROLE: {role.GetType()}");
        Debug.Log(string.Format("Politician getting info of role {0}", role.GetType()));
        ActedInfo newInfo = role.GetBluffInfo(charRef);
        return newInfo;
    }

    public override ActedInfo GetBluffInfo(Character charRef)
    {
        ActedInfo newInfo = poliInfoRoles[UnityEngine.Random.Range(0, poliInfoRoles.Count)].GetInfo(charRef);
        return newInfo;
    }

    public List<Role> poliInfoRoles = new List<Role>()
    {
        new Empath(),
        new Scout(),
        new Investigator(),
        new BountyHunter(),
        new Lookout(),
        new Knitter(),
        new Tracker(),
        new Shugenja(),
        new Noble(),
        new Bishop(),
        new Archivist(),
        new Acrobat2(),
        new w_Arithmetician(),
        new w_Clairvoyant(),
        new w_Sentinel()
    };
    public w_Politician() : base(ClassInjector.DerivedConstructorPointer<w_Politician>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Politician(System.IntPtr ptr) : base(ptr)
    {
    }
}


