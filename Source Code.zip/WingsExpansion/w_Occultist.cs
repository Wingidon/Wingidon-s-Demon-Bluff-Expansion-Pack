﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using HarmonyLib;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Occultist : Role
{
    public override string Description
    {
        get
        {
            return "I am a Good Minion.";
        }
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            Il2CppSystem.Collections.Generic.List<CharacterData> deckMinions = new Il2CppSystem.Collections.Generic.List<CharacterData>();
            foreach (CharacterData c in Gameplay.Instance.GetScriptCharactersOfAlignment(EAlignment.Evil))
            {
                deckMinions.Add(c);
            }
            CharacterData targetMinion = deckMinions[UnityEngine.Random.RandomRangeInt(0, deckMinions.Count)];
            Health health = PlayerController.PlayerInfo.health;
            health.AddMaxHp(2);
            health.Heal(2);
            charRef.statuses.AddStatus(w_OccultistIsAMoron.w_occultistIsAMoron, charRef);
            charRef.Init(ProjectContext.Instance.gameData.GetCharacterDataOfId(targetMinion.characterId)); // THIS DOESN'T SEEM TO BE WORKING!
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        
    }
    public w_Occultist() : base(ClassInjector.DerivedConstructorPointer<w_Occultist>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Occultist(System.IntPtr ptr) : base(ptr)
    {
    }
    public static class w_OccultistIsAMoron
    {
        public static ECharacterStatus w_occultistIsAMoron = (ECharacterStatus)645;

        [HarmonyPatch(typeof(Character), nameof(Character.RevealAllReal))]
        public static class pvt
        {
            public static void Postfix(Character __instance)
            {
                if (__instance.statuses.Contains(w_occultistIsAMoron))
                {
                    //__instance.chName.text = __instance.dataRef.name.ToUpper() + "<color=#00FF00><size=18>\n<Occultist></color></size>";
                    __instance.chName.text = "OCCULTIST";
                }
            }
        }
    }
}


