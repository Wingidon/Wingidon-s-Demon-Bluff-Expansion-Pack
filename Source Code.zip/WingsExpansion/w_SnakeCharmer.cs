﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using HarmonyLib;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_SnakeCharmer : Role
{
    public w_SnakeCharmer() : base(ClassInjector.DerivedConstructorPointer<w_SnakeCharmer>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_SnakeCharmer(System.IntPtr ptr) : base(ptr)
    {

    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            Character pickedCharacter = charRef;
            Il2CppSystem.Collections.Generic.List<Character> viableCharacters = new Il2CppSystem.Collections.Generic.List<Character>();
            viableCharacters = Characters.Instance.FilterRealCharacterType(Gameplay.CurrentCharacters, ECharacterType.Villager);
            viableCharacters = Characters.Instance.FilterCharacterMissingStatus(viableCharacters, ECharacterStatus.Corrupted);
            viableCharacters = Characters.Instance.FilterCharacterMissingStatus(viableCharacters, SnakeCharmed.snakeCharmed);

            if (viableCharacters.Count == 0) return;

            int randomId = UnityEngine.Random.Range(0, viableCharacters.Count);
            pickedCharacter = viableCharacters[randomId];

            pickedCharacter.statuses.AddStatus(ECharacterStatus.Corrupted, charRef);
            pickedCharacter.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
            pickedCharacter.statuses.AddStatus(SnakeCharmed.snakeCharmed, charRef);

        }
    }
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("");
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        return new ActedInfo("");
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
    }
    public string ConjourInfo()
    {
        return "";
    }
    public override bool CheckIfCanBeKilled(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> charmedCharacters = new Il2CppSystem.Collections.Generic.List<Character>();
        charmedCharacters = Characters.Instance.FilterCharacterContainsStatus(Gameplay.CurrentCharacters, SnakeCharmed.snakeCharmed);
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        string line = "Info";
        selection.Add(charmedCharacters[0]);
        line = string.Format("I poisoned the {0}", charmedCharacters[0].GetRegisterAs().name);
        ActedInfo actedInfo = new ActedInfo(line, selection);
        charRef.ShowActed(actedInfo);
        return true;
    }

    public override CharacterData GetBluffIfAble(Character charRef)
    {
        int diceRoll = Calculator.RollDice(10);
        CharacterData bluff = Characters.Instance.GetRandomUniqueBluff();

        //List<CharacterData> notInPlayCh = Gameplay.Instance.GetScriptCharacters();
        //notInPlayCh = Characters.Instance.FilterAlignmentCharacters(notInPlayCh, EAlignment.Good);
        //notInPlayCh = Characters.Instance.FilterBluffableCharacters(notInPlayCh);
        //return notInPlayCh[UnityEngine.Random.Range(0, notInPlayCh.Count - 1)];

        if (diceRoll < 5)
        {
            // 100% Double Claim
            bluff = Characters.Instance.GetRandomDuplicateBluff();
        }
        else
        {
            // Become a new character
            bluff = Characters.Instance.GetRandomUniqueBluff();
            Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);
        }
        return bluff;
    }
    public static class SnakeCharmed
    {
        public static ECharacterStatus snakeCharmed = (ECharacterStatus)543;
    }
}


