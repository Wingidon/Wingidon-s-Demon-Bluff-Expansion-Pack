﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_SnakeCharmer : Role
{
    public w_SnakeCharmer() : base(ClassInjector.DerivedConstructorPointer<w_SnakeCharmer>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_SnakeCharmer(System.IntPtr ptr) : base(ptr)
    {

    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        Character pickedCharacter = charRef;
        if (trigger == ETriggerPhase.Start)
        {

            Il2CppSystem.Collections.Generic.List<Character> viableCharacters = Gameplay.CurrentCharacters;
            viableCharacters = Characters.Instance.FilterRealCharacterType(viableCharacters, ECharacterType.Villager);
            viableCharacters = Characters.Instance.FilterCharacterMissingStatus(viableCharacters, ECharacterStatus.Corrupted);

            if (viableCharacters.Count == 0) return;

            int randomId = UnityEngine.Random.Range(0, viableCharacters.Count);
            pickedCharacter = viableCharacters[randomId];

            pickedCharacter.statuses.AddStatus(ECharacterStatus.Corrupted, charRef);
            pickedCharacter.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);

        }
        if (trigger == ETriggerPhase.OnExecuted)
        {
            charRef.GetCurrentActedInfo().desc = string.Format("I poisoned the {0}", pickedCharacter.GetRegisterAs().name);
            charRef.ShowActed(charRef.GetCurrentActedInfo());
        }

    }
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("");
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        return new ActedInfo("");
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
    }
    public string ConjourInfo()
    {
        return "";
    }

    public override CharacterData GetBluffIfAble(Character charRef)
    {
        int diceRoll = Calculator.RollDice(10);
        CharacterData bluff = Characters.Instance.GetRandomUniqueBluff();

        //List<CharacterData> notInPlayCh = Gameplay.Instance.GetScriptCharacters();
        //notInPlayCh = Characters.Instance.FilterAlignmentCharacters(notInPlayCh, EAlignment.Good);
        //notInPlayCh = Characters.Instance.FilterBluffableCharacters(notInPlayCh);
        //return notInPlayCh[UnityEngine.Random.Range(0, notInPlayCh.Count - 1)];

        if (diceRoll < 5)
        {
            // 100% Double Claim
            bluff = Characters.Instance.GetRandomDuplicateBluff();
        }
        else
        {
            // Become a new character
            bluff = Characters.Instance.GetRandomUniqueBluff();
            Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);
        }
        return bluff;
    }
}


