﻿using ExpansionPack;
using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSystem;
using MelonLoader;
using System;
using System.Runtime.Intrinsics.X86;
using UnityEngine;
using UnityEngine.Playables;
using HarmonyLib;
using static Il2CppSystem.Array;
using System.Net.NetworkInformation;
using static Il2Cpp.GameplayEvents;

[assembly: MelonInfo(typeof(MainMod), "Wingidon's Expansion Pack", "1.0", "Wingidon")]
[assembly: MelonGame("UmiArt", "Demon Bluff")]

namespace ExpansionPack;
public class MainMod : MelonMod
{
    public override void OnInitializeMelon()
    {
        ClassInjector.RegisterTypeInIl2Cpp<w_Prince>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Clairvoyant>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Forager>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Arithmetician>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Scavenger>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Sentinel>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Spy>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Lunatic>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Swarm_Good>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Swarm_Evil>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Turncoat>();
        ClassInjector.RegisterTypeInIl2Cpp<w_Illusionist>();
        ClassInjector.RegisterTypeInIl2Cpp<w_TwinDemon>();
        ClassInjector.RegisterTypeInIl2Cpp<w_TwinDemonTwin>();
    }
    public override void OnLateInitializeMelon()
    {
        GameObject content = GameObject.Find("Game/Gameplay/Content");
        NightPhase nightPhase = content.GetComponent<NightPhase>();

        CharacterData w_prince = new CharacterData();
        w_prince.role = new w_Prince();
        w_prince.name = "Prince";
        w_prince.description = "Learn that exactly 1 of 2 characters is Disguised.";
        w_prince.flavorText = "\"Secretly wishes that his mother was more trusting.\"";
        w_prince.hints = "";
        w_prince.ifLies = "Both characters in my info are <color=#99FF99>Honest</color>.";
        w_prince.picking = false;
        w_prince.startingAlignment = EAlignment.Good;
        w_prince.type = ECharacterType.Villager;
        w_prince.bluffable = true;
        w_prince.characterId = "Prince_WING";
        w_prince.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_prince.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_prince.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_prince.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_clairvoyant = new CharacterData();
        w_clairvoyant.role = new w_Clairvoyant();
        w_clairvoyant.name = "Clairvoyant";
        w_clairvoyant.description = "Learn 2 characters: Both are Good, or both are Evil.";
        w_clairvoyant.flavorText = "\"Sees a friendship in the future. Doesn't always understand why.\"";
        w_clairvoyant.hints = "";
        w_clairvoyant.ifLies = "";
        w_clairvoyant.picking = false;
        w_clairvoyant.startingAlignment = EAlignment.Good;
        w_clairvoyant.type = ECharacterType.Villager;
        w_clairvoyant.bluffable = true;
        w_clairvoyant.characterId = "Clairvoyant_WING";
        w_clairvoyant.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_clairvoyant.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_clairvoyant.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_clairvoyant.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_forager = new CharacterData();
        w_forager.role = new w_Forager();
        w_forager.name = "Forager";
        w_forager.description = "<b>Pick 1 character:</b>\nLearn if they are a Villager.";
        w_forager.flavorText = "\"Her instructions are clear, it's just that her assistants don't follow them.\"";
        w_forager.hints = "";
        w_forager.ifLies = "";
        w_forager.picking = true;
        w_forager.startingAlignment = EAlignment.Good;
        w_forager.type = ECharacterType.Villager;
        w_forager.abilityUsage = EAbilityUsage.ResetAfterNight;
        w_forager.bluffable = true;
        w_forager.characterId = "Forager_WING";
        w_forager.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_forager.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_forager.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_forager.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_gambler = new CharacterData();
        w_gambler.role = new w_Gambler();
        w_gambler.name = "Gambler";
        w_gambler.description = "<b>Pick 1 character:</b>\nThey die, but don't reveal their <color=#FFFFFF>True Role</color>.\nFor each <b>Unrevealed</b> character, deal 1 damage to you if Villager picked, or 2 healing otherwise.";
        w_gambler.flavorText = "\"She likes her odds, perhaps a little too much.\"";
        w_gambler.hints = "";
        w_gambler.ifLies = "I heal you when you pick Villagers and damage you when you don't.";
        w_gambler.picking = true;
        w_gambler.startingAlignment = EAlignment.Good;
        w_gambler.type = ECharacterType.Villager;
        w_gambler.abilityUsage = EAbilityUsage.Once;
        w_gambler.bluffable = true;
        w_gambler.characterId = "Gambler_WING";
        w_gambler.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_gambler.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_gambler.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_gambler.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_sentinel = new CharacterData();
        w_sentinel.role = new w_Sentinel();
        w_sentinel.name = "Sentinel";
        w_sentinel.description = "Learn that exactly 1 of 2 characters is Corrupted.";
        w_sentinel.flavorText = "\"She rarely ever rejects anyone from the village.\nShe does have some suspicions though.\"";
        w_sentinel.hints = "";
        w_sentinel.ifLies = "Both characters in my info are <color=#99FF99>Pure</color>.";
        w_sentinel.picking = false;
        w_sentinel.startingAlignment = EAlignment.Good;
        w_sentinel.type = ECharacterType.Villager;
        w_sentinel.bluffable = true;
        w_sentinel.characterId = "Sentinel_WING";
        w_sentinel.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_sentinel.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_sentinel.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_sentinel.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_spy = new CharacterData();
        w_spy.role = new w_Spy();
        w_spy.name = "Spy";
        w_spy.description = "Learn an Evil role that has not been Revealed yet (or that all have been).";
        w_spy.flavorText = "\"Thinks he's extremely stealthy. He's not.\"";
        w_spy.hints = "If I am Revealed last, Learn that 1 of 2 characters is a particular Evil.";
        w_spy.ifLies = "";
        w_spy.picking = false;
        w_spy.startingAlignment = EAlignment.Good;
        w_spy.type = ECharacterType.Villager;
        w_spy.bluffable = true;
        w_spy.characterId = "Spy_WING";
        w_spy.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_spy.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_spy.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_spy.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_arithmetician = new CharacterData();
        w_arithmetician.role = new w_Arithmetician();
        w_arithmetician.name = "Arithmetician";
        w_arithmetician.description = "Learn the sum of all Evil characters' positions.";
        w_arithmetician.flavorText = "\"Her accusations are so complicated that nobody even knows what they're being accused of.\"";
        w_arithmetician.hints = "";
        w_arithmetician.ifLies = "";
        w_arithmetician.picking = false;
        w_arithmetician.startingAlignment = EAlignment.Good;
        w_arithmetician.type = ECharacterType.Villager;
        w_arithmetician.bluffable = true;
        w_arithmetician.characterId = "Arithmetician_WING";
        w_arithmetician.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_arithmetician.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_arithmetician.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_arithmetician.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_politician = new CharacterData(); // Politician doing some weird shit and not flipping half the time. Scrapping until I can work out wtf's going on
        //w_politician.role = new w_Politician();
        //w_politician.name = "Politician";
        //w_politician.description = "<b>Game Start:</b>\nI am Corrupted.\n\nLearn random false info.\nBeing Corrupted does not make me Lie.";
        //w_politician.flavorText = "\"He just showed up one day and started bossing people around.\"";
        //w_politician.hints = "I Register as <color=#FF9999>Truthful</color>, despite being Corrupted.\nI cannot be <color=#FF9999>Cured</color>, though truthful <color=#C080FF>Alchemists</color> will claim they <color=#FF9999>Cured</color> me.";
        //w_politician.ifLies = "I do not become Corrupted. Learn true info instead.";
        //w_politician.picking = false;
        //w_politician.startingAlignment = EAlignment.Good;
        //w_politician.type = ECharacterType.Villager;
        //w_politician.bluffable = true;
        //w_politician.characterId = "Politician_WING";
        //w_politician.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_politician.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_politician.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_politician.color = new Color(1f, 0.935f, 0.7302f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_politician);

        CharacterData w_scavenger = new CharacterData();
        w_scavenger.role = new w_Scavenger();
        w_scavenger.name = "Scavenger";
        w_scavenger.description = "<b>Activate Me:</b>\nFor every dead Evil character, gain 1 Max Health and <color=#99FF99>Heal</color> you for 2 health.";
        w_scavenger.flavorText = "\"They've always hated the term 'loot goblin', despite how perfectly it describes them.\"";
        w_scavenger.hints = "";
        w_scavenger.ifLies = "<b>Activate Me:</b>\nFor every dead Evil character, deal 2 <color=#FF9999>Damage</color> to you, then I die.\nIf I die this way, I do not reveal my <color=#FFFFFF>True Role</color>.";
        w_scavenger.picking = true;
        w_scavenger.startingAlignment = EAlignment.Good;
        w_scavenger.type = ECharacterType.Villager;
        w_scavenger.bluffable = true;
        w_scavenger.characterId = "Scavenger_WING";
        w_scavenger.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_scavenger.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_scavenger.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_scavenger.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_pirate = new CharacterData();
        //w_pirate.role = new w_Pirate();
        //w_pirate.name = "Pirate";
        //w_pirate.description = "<b>At Night</b>\nKill and Reveal 1 <color=#99FF99>Pure</color> Good character.\nDeal 1 damage to you.";
        //w_pirate.flavorText = "\"Her accent is authentic, but she's never actually been at sea.\"";
        //w_pirate.hints = "'<color=#99FF99>Pure</color>' means 'Not Corrupted'.";
        //w_pirate.ifLies = "I do not kill.";
        //w_pirate.picking = false;
        //w_pirate.startingAlignment = EAlignment.Good;
        //w_pirate.type = ECharacterType.Villager;
        //w_pirate.bluffable = true;
        //w_pirate.characterId = "Pirate_WING";
        //w_pirate.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_pirate.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_pirate.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_pirate.color = new Color(1f, 0.935f, 0.7302f);
        //nightPhase.nightCharactersOrder.Add(w_pirate);

        CharacterData w_devout = new CharacterData();
        w_devout.role = new w_Devout();
        w_devout.name = "Devout";
        w_devout.description = "<b>Game Start:</b>\n<b>Reveal</b> me.\nLearn 1 Outcast character.";
        w_devout.flavorText = "\"Your greatest follower, or so they claim.\"";
        w_devout.hints = "Characters who Disguise as me, even if <color=#99FF99>Truthful</color>, will not be <b>Revealed</b> on <b>Game Start</b>.\n\nI can bypass misregistration.";
        w_devout.ifLies = "";
        w_devout.picking = false;
        w_devout.startingAlignment = EAlignment.Good;
        w_devout.type = ECharacterType.Villager;
        w_devout.bluffable = false;
        w_devout.characterId = "Devout_WING";
        w_devout.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_devout.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_devout.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_devout.color = new Color(1f, 0.935f, 0.7302f);
        Characters.Instance.startGameActOrder = insertAfterAct("Alchemist", w_devout);

        //CharacterData w_sheriff = new CharacterData(); // SCRAPPED
        //w_sheriff.role = new w_Sheriff();
        //w_sheriff.name = "Sheriff";
        //w_sheriff.description = "Learn 1 role that is being used as a Disguise.";
        //w_sheriff.flavorText = "\"Paid to deal with common criminals, not demons.\"";
        //w_sheriff.hints = "";
        //w_sheriff.ifLies = "";
        //w_sheriff.picking = false;
        //w_sheriff.startingAlignment = EAlignment.Good;
        //w_sheriff.type = ECharacterType.Villager;
        //w_sheriff.bluffable = true;
        //w_sheriff.characterId = "Sheriff_WING";
        //w_sheriff.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_sheriff.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_sheriff.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_sheriff.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_slayerRework = new CharacterData();
        w_slayerRework.role = new w_SlayerRework();
        w_slayerRework.name = "Convict";
        w_slayerRework.description = "<b>Pick 1 character:</b>\nThey die, but don't reveal their <color=#FFFFFF>True Role</color>.\nLearn their alignment.";
        w_slayerRework.flavorText = "\"Was scheduled for a trial, but then the Bombardier got sentenced.\"";
        w_slayerRework.hints = "";
        w_slayerRework.ifLies = "I still kill my target, but Lie about their alignment.";
        w_slayerRework.picking = true;
        w_slayerRework.startingAlignment = EAlignment.Good;
        w_slayerRework.type = ECharacterType.Villager;
        w_slayerRework.abilityUsage = EAbilityUsage.Once;
        w_slayerRework.bluffable = true;
        w_slayerRework.characterId = "Slayer_WING";
        w_slayerRework.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_slayerRework.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_slayerRework.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_slayerRework.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_performer = new CharacterData();
        w_performer.role = new w_Performer();
        w_performer.name = "Performer";
        w_performer.description = "Learn 1 Evil character.\nIf I am adjacent to Evil, Learn false info.";
        w_performer.flavorText = "\"What a wonderful performance!\n...is what I would say if her background characters weren't saboteurs.\"";
        w_performer.hints = "If I Learn false info due only to my ability, it does not count as Lying, as my ability is functioning as intended.";
        w_performer.ifLies = "My info is the opposite of what I would normally Learn.";
        w_performer.picking = false;
        w_performer.startingAlignment = EAlignment.Good;
        w_performer.type = ECharacterType.Villager;
        w_performer.bluffable = true;
        w_performer.characterId = "Performer_WING";
        w_performer.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_performer.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_performer.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_performer.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_lamb = new CharacterData();
        w_lamb.role = new w_Lamb();
        w_lamb.name = "Lamb";
        w_lamb.description = "Learn how far from me to a particular Outcast.";
        w_lamb.flavorText = "\"Looking for a shepherd.\nAn adequate one, that is.\"";
        w_lamb.hints = "If an Outcast Disguised as me is truthful and is also the only Outcast, they will say that there are no Outcasts.";
        w_lamb.ifLies = "";
        w_lamb.picking = false;
        w_lamb.startingAlignment = EAlignment.Good;
        w_lamb.type = ECharacterType.Villager;
        w_lamb.bluffable = true;
        w_lamb.characterId = "Lamb_WING";
        w_lamb.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_lamb.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_lamb.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_lamb.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_introvert = new CharacterData();
        w_introvert.role = new w_Introvert();
        w_introvert.name = "Introvert";
        w_introvert.description = "Learn 2 characters that sit within 2 seats of me.";
        w_introvert.flavorText = "\"People think she's nice to be around.\nShe hates it.\"";
        w_introvert.hints = "";
        w_introvert.ifLies = "At least one of my statements is incorrect.";
        w_introvert.picking = false;
        w_introvert.startingAlignment = EAlignment.Good;
        w_introvert.type = ECharacterType.Villager;
        w_introvert.bluffable = true;
        w_introvert.characterId = "Introvert_WING";
        w_introvert.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_introvert.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_introvert.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_introvert.color = new Color(1f, 0.935f, 0.7302f);

        CharacterData w_chiromancer = new CharacterData();
        w_chiromancer.role = new w_Chiromancer();
        w_chiromancer.name = "Chiromancer";
        w_chiromancer.description = "Learn 3 characters and which Evil role each is.\nOnly 1 is correct.";
        w_chiromancer.flavorText = "\"She sees several possible futures, and none of them are good.\"";
        w_chiromancer.hints = "";
        w_chiromancer.ifLies = "None are correct.";
        w_chiromancer.picking = false;
        w_chiromancer.startingAlignment = EAlignment.Good;
        w_chiromancer.type = ECharacterType.Villager;
        w_chiromancer.bluffable = true;
        w_chiromancer.characterId = "Chiromancer_WING";
        w_chiromancer.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_chiromancer.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_chiromancer.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_chiromancer.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_politician = new CharacterData();
        //w_politician.role = new w_Politician();
        //w_politician.name = "Politician";
        //w_politician.description = "<b>Game Start:</b>\nI am Corrupted.\n\nI Register as Lying.\nLearn random false info.";
        //w_politician.flavorText = "\"He just showed up one day and started bossing people around.\"";
        //w_politician.hints = "";
        //w_politician.ifLies = "My info is true instead.\nI still Register as Lying.";
        //w_politician.picking = false;
        //w_politician.startingAlignment = EAlignment.Good;
        //w_politician.type = ECharacterType.Villager;
        //w_politician.bluffable = true;
        //w_politician.characterId = "Politician_WING";
        //w_politician.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_politician.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_politician.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_politician.color = new Color(1f, 0.935f, 0.7302f);

        //CharacterData w_caravan = new CharacterData();
        //w_caravan.role = new w_Caravan();
        //w_caravan.name = "Caravan";
        //w_caravan.description = "2 characters Register as each other's role and alignment.\nLearn 1 of their roles.\n\n<b>Execute Me:</b>\nLearn the other role I affected.";
        //w_caravan.flavorText = "\"Nobody knows where the caravan goes.\nExcept the driver, that is.\"";
        //w_caravan.hints = "";
        //w_caravan.ifLies = "";
        //w_caravan.picking = false;
        //w_caravan.startingAlignment = EAlignment.Good;
        //w_caravan.type = ECharacterType.Outcast;
        //w_caravan.bluffable = false;
        //w_caravan.characterId = "Caravan_WING";
        //w_caravan.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_caravan.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        //w_caravan.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        //w_caravan.color = new Color(0.9647f, 1f, 0.4471f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_caravan);

        //CharacterData w_henchman = new CharacterData();
        //w_henchman.role = new w_Henchman();
        //w_henchman.name = "Henchman";
        //w_henchman.description = "I start Evil, then become the alignment of the 1st character you Execute.";
        //w_henchman.flavorText = "\"His favourite phrases include 'Got it, boss!', 'You're the boss, boss.' and 'You got a problem with the boss?!'\"";
        //w_henchman.hints = "I only Lie if I am Corrupted.\n\nI have a 50% chance to be Corrupted.\n\nTake 2 less damage when you Execute me.";
        //w_henchman.ifLies = "";
        //w_henchman.picking = false;
        //w_henchman.startingAlignment = EAlignment.Good;
        //w_henchman.type = ECharacterType.Outcast;
        //w_henchman.bluffable = false;
        //w_henchman.characterId = "Henchman_WING";
        //w_henchman.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_henchman.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        //w_henchman.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        //w_henchman.color = new Color(0.9647f, 1f, 0.4471f);

        CharacterData w_lunatic = new CharacterData();
        w_lunatic.role = new w_Lunatic();
        w_lunatic.name = "Lunatic";
        w_lunatic.description = "I Disguise.\nI have a 50% chance to be Corrupted.";
        w_lunatic.flavorText = "\"Constantly attempts to search everyone's shadows for the truth.\nMight have taken the Poet's writings a bit too literally.\"";
        w_lunatic.hints = "I only Lie if I am Corrupted.\nThe <color=#C080FF>Alchemist</color> cannot Cure me.\n\nTake 2 less damage when you Execute me.";
        w_lunatic.ifLies = "";
        w_lunatic.picking = false;
        w_lunatic.startingAlignment = EAlignment.Good;
        w_lunatic.type = ECharacterType.Outcast;
        w_lunatic.bluffable = false;
        w_lunatic.characterId = "Lunatic_WING";
        w_lunatic.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_lunatic.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        w_lunatic.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        w_lunatic.color = new Color(0.9647f, 1f, 0.4471f);

        CharacterData w_marionette = new CharacterData();
        w_marionette.role = new w_Marionette();
        w_marionette.name = "Marionette";
        w_marionette.description = "<b>Game Start:</b>\nI sit next to the Demon, if possible.\n\nI Register as a <color=#FF9999>Puppet</color>.\nI Lie and Disguise.";
        w_marionette.flavorText = "\"You ever feel like you're losing control over your life?\"";
        w_marionette.hints = "You take 3 damage instead of 5 when you Execute me.\n\nIf the <color=#FF9999>Chancellor</color> creates me, I immediately move to be next to the Demon.\nThis can result in a <color=#FF9999>Chancellor</color> with no Outcast neighbours.";
        w_marionette.ifLies = "";
        w_marionette.picking = false;
        w_marionette.startingAlignment = EAlignment.Good;
        w_marionette.type = ECharacterType.Outcast;
        w_marionette.bluffable = false;
        w_marionette.characterId = "Marionette_WING";
        w_marionette.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_marionette.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        w_marionette.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        w_marionette.color = new Color(0.9647f, 1f, 0.4471f);
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_marionette);

        //CharacterData w_occultist = new CharacterData();
        //w_occultist.role = new w_Occultist();
        //w_occultist.name = "Occultist";
        //w_occultist.description = "<b>Game Start:</b>\nI become a random Good Minion.\nYou have 2 extra Max Health.";
        //w_occultist.flavorText = "\"They tampered with forces beyond their control and got what they deserved.\"";
        //w_occultist.hints = "I have the ability of the Minion I become, and also copy their Lying and Disguising behaviour.\nWhen I am Executed, I show up with the Minion's Evil colours and art, but with the name \'Occultist\'. Don't get confused.";
        //w_occultist.ifLies = "";
        //w_occultist.picking = false;
        //w_occultist.startingAlignment = EAlignment.Good;
        //w_occultist.type = ECharacterType.Outcast;
        //w_occultist.bluffable = false;
        //w_occultist.characterId = "Occultist_WING";
        //w_occultist.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_occultist.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        //w_occultist.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        //w_occultist.color = new Color(0.9647f, 1f, 0.4471f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Baa", w_occultist);

        CharacterData w_revolutionary = new CharacterData();
        w_revolutionary.role = new w_Revolutionary();
        w_revolutionary.name = "Revolutionary";
        w_revolutionary.description = "<b>On Death:</b>\nI Execute an adjacent Villager to me, if possible.\n\nI Disguise.";
        w_revolutionary.flavorText = "\"Has attempted to kill the Empress on multiple occasions.\nUsually gets held back by the Knight or Slayer.\"";
        w_revolutionary.hints = "You take 3 damage instead of 5 when you Execute me.\nI may attempt to Execute a <color=#C080FF>Knight</color>, but I cannot kill him.";
        w_revolutionary.ifLies = "";
        w_revolutionary.picking = false;
        w_revolutionary.startingAlignment = EAlignment.Good;
        w_revolutionary.type = ECharacterType.Outcast;
        w_revolutionary.bluffable = false;
        w_revolutionary.characterId = "Revolutionary_WING";
        w_revolutionary.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_revolutionary.cardBgColor = new Color(0.1020f, 0.0667f, 0.0392f);
        w_revolutionary.cardBorderColor = new Color(0.7843f, 0.6471f, 0.0f);
        w_revolutionary.color = new Color(0.9647f, 1f, 0.4471f); // NEXT ADDITION: PROVOCATEUR

        CharacterData w_turncoat = new CharacterData();
        w_turncoat.role = new w_Turncoat();
        w_turncoat.name = "Turncoat";
        w_turncoat.description = "I Disguise as an in-play character.";
        w_turncoat.flavorText = "\"Hurt me with the truth, but don't comfort me with a lie.\"";
        w_turncoat.hints = "I Register as Lying if (and only if) I am Disguised as the <color=#B656DD>Knight</color> or the <color=#C8A500>Bombardier</color>, whose abilities I cannot gain.\nOtherwise, I Register as <color=#99FF99>Truthful</color>.";
        w_turncoat.ifLies = "";
        w_turncoat.picking = false;
        w_turncoat.startingAlignment = EAlignment.Evil;
        w_turncoat.type = ECharacterType.Minion;
        w_turncoat.bluffable = false;
        w_turncoat.characterId = "Turncoat_WING";
        w_turncoat.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_turncoat.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_turncoat.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_turncoat.color = new Color(0.8510f, 0.4549f, 0.0f);

        CharacterData w_swarm_good = new CharacterData();
        w_swarm_good.role = new w_Swarm_Good();
        w_swarm_good.name = "Swarm (Good)";
        w_swarm_good.description = "<b>Game Start:</b>\n2 other Good Villagers become <color=#FF9999>Swarm</color>. Both are Evil.\n\nLearn 4 characters, 2 of which are <color=#FF9999>Swarm</color>.";
        w_swarm_good.flavorText = "\"This one seems defective.\nPerhaps they can help you.\"";
        w_swarm_good.hints = "";
        w_swarm_good.ifLies = "Learn 'I feel off'.\nNote that I cannot be Disguised as, so the only time I will Lie is if I am somehow forced to.";
        w_swarm_good.picking = false;
        w_swarm_good.startingAlignment = EAlignment.Good;
        w_swarm_good.type = ECharacterType.Minion;
        w_swarm_good.bluffable = false;
        w_swarm_good.characterId = "Swarm_Good_WING";
        w_swarm_good.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_swarm_good.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        w_swarm_good.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        w_swarm_good.color = new Color(1f, 0.935f, 0.7302f);
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_swarm_good);

        CharacterData w_swarm_evil = new CharacterData();
        w_swarm_evil.role = new w_Swarm_Evil();
        w_swarm_evil.name = "Swarm (Evil)";
        w_swarm_evil.description = "<b>Game Start:</b>\n2 other Good Villagers become <color=#FF9999>Swarm</color>. One is Good, one is Evil.\n\nI Lie and Disguise.";
        w_swarm_evil.flavorText = "\"Keep your guard up, or they'll outnumber and overwhelm you.\"";
        w_swarm_evil.hints = "";
        w_swarm_evil.ifLies = "";
        w_swarm_evil.picking = false;
        w_swarm_evil.startingAlignment = EAlignment.Evil;
        w_swarm_evil.type = ECharacterType.Minion;
        w_swarm_evil.bluffable = false;
        w_swarm_evil.characterId = "Swarm_Evil_WING";
        w_swarm_evil.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_swarm_evil.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_swarm_evil.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_swarm_evil.color = new Color(0.8510f, 0.4549f, 0.0f);

        //CharacterData w_snakecharmer = new CharacterData();
        //w_snakecharmer.role = new w_SnakeCharmer();
        //w_snakecharmer.name = "Snake Charmer";
        //w_snakecharmer.description = "<b>Game Start:</b>\n1 Good Villager is Corrupted.\n\n<b>Execute Me:</b>\nLearn the role of the Villager I Corrupted.\n\nI Lie and Disguise.";
        //w_snakecharmer.flavorText = "\"The snakes aren't deadly, but their venom still hurts.\"";
        //w_snakecharmer.hints = "";
        //w_snakecharmer.ifLies = "";
        //w_snakecharmer.picking = false;
        //w_snakecharmer.startingAlignment = EAlignment.Evil;
        //w_snakecharmer.type = ECharacterType.Minion;
        //w_snakecharmer.bluffable = false;
        //w_snakecharmer.characterId = "SnakeCharmer_WING";
        //w_snakecharmer.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_snakecharmer.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_snakecharmer.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_snakecharmer.color = new Color(1f, 0.3804f, 0.3804f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Poisoner", w_snakecharmer);

        CharacterData w_undying = new CharacterData();
        w_undying.role = new w_Undying();
        w_undying.name = "Undying";
        w_undying.description = "<b>Game Start:</b>\n1 Good Villager might become an <color=#FF9999>Acolyte</color>.\n\n<b>Execute Me:</b>\nIf other Evil characters still live, I don't die; deal 4 damage to you.";
        w_undying.flavorText = "\"Laughs in the face of death\nThat is, until it has no teammates to fall back on.\"";
        w_undying.hints = "Attempting to kill me using a character ability counts as Executing me.\n<i>You're not getting me that easily.</i>";
        w_undying.ifLies = "";
        w_undying.picking = false;
        w_undying.startingAlignment = EAlignment.Evil;
        w_undying.type = ECharacterType.Minion;
        w_undying.bluffable = false;
        w_undying.characterId = "Undying_WING";
        w_undying.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_undying.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_undying.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_undying.color = new Color(0.8510f, 0.4549f, 0.0f);
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_undying);

        CharacterData w_professional = new CharacterData();
        w_professional.role = new w_Professional();
        w_professional.name = "Professional";
        w_professional.description = "I Lie and Disguise.\nI Register as Good and as my Disguise.";
        w_professional.flavorText = "\"If you're going to be committing crimes, you really ought to clean up the mess behind you.\"";
        w_professional.hints = "If I am Disguised as the <color=#C080FF>Confessor</color>, I will say \"I am Good\".\nI can also be converted by the <color=#C080FF>Baker</color>. If this happens, I will appear 'Evil' when Executed, and will not convert anyone else.";
        w_professional.ifLies = "";
        w_professional.picking = false;
        w_professional.startingAlignment = EAlignment.Evil;
        w_professional.type = ECharacterType.Minion;
        w_professional.bluffable = false;
        w_professional.characterId = "Professional_WING";
        w_professional.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_professional.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_professional.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_professional.color = new Color(0.8510f, 0.4549f, 0.0f);

        CharacterData w_saboteur = new CharacterData();
        w_saboteur.role = new w_Saboteur();
        w_saboteur.name = "Diversionist";
        w_saboteur.description = "<b>Game Start:</b>\n1 Good Villager furthest away from me is Corrupted.\n\nI Lie and Disguise.";
        w_saboteur.flavorText = "\"The Architect has been trying to work out what was wrong with the Gemcrafter's house for weeks.\nHere's a hint: Sabotage.\"";
        w_saboteur.hints = "I Corrupt the Good Villager furthest away from me, but they do not need to be directly opposite to me.";
        w_saboteur.ifLies = "";
        w_saboteur.picking = false;
        w_saboteur.startingAlignment = EAlignment.Evil;
        w_saboteur.type = ECharacterType.Minion;
        w_saboteur.bluffable = false;
        w_saboteur.characterId = "Saboteur_WING";
        w_saboteur.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_saboteur.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_saboteur.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_saboteur.color = new Color(0.8510f, 0.4549f, 0.0f);
        Characters.Instance.startGameActOrder = insertBeforeAct("Pooka", w_saboteur);

        /*CharacterData w_toxomancer = new CharacterData();
        w_toxomancer.role = new w_Toxomancer();
        w_toxomancer.name = "Toxomancer";
        w_toxomancer.description = "For every 3 cards you <b>Reveal</b>, I <color=#009900>Poison</color> 1 Good Villager.\nDeal 1 damage to you when they die.\n\nI Lie and Disguise.";
        w_toxomancer.flavorText = "\"Most Minions like to keep it subtle.\nThis one prefers to go loud.\"";
        w_toxomancer.hints = "<color=#009900>Poisoned</color> characters Lie and are Corrupted.\nAfter 2 cards are Revealed, they die, even if the <color=#FF9999>Toxomancer</color> is dead.\n\nIf a character is <color=#009900>Poisoned</color> after their ability has already been used, their information does not change.";
        w_toxomancer.ifLies = "";
        w_toxomancer.picking = false;
        w_toxomancer.startingAlignment = EAlignment.Evil;
        w_toxomancer.type = ECharacterType.Minion;
        w_toxomancer.bluffable = false;
        w_toxomancer.characterId = "Toxomancer_WING";
        w_toxomancer.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_toxomancer.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_toxomancer.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_toxomancer.color = new Color(0.8510f, 0.4549f, 0.0f);*/

        //CharacterData w_disguiser = new CharacterData();
        //w_disguiser.role = new w_Disguiser();
        //w_disguiser.name = "Disguiser";
        //w_disguiser.description = "1 Good Villager Disguises.\n\nI Lie and Disguise.";
        //w_disguiser.flavorText = "\"A silver tongue, some sweet words and a good disguise are all they need to trick someone.\"";
        //w_disguiser.hints = "The Villager caused to Disguise by me follows standard Minion Disguise rules.\nThey do NOT Lie unless they for some reason already would.";
        //w_disguiser.ifLies = "";
        //w_disguiser.picking = false;
        //w_disguiser.startingAlignment = EAlignment.Evil;
        //w_disguiser.type = ECharacterType.Minion;
        //w_disguiser.bluffable = false;
        //w_disguiser.characterId = "Disguiser_WING";
        //w_disguiser.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_disguiser.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_disguiser.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_disguiser.color = new Color(1f, 0.3804f, 0.3804f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_disguiser);

        //CharacterData w_chronomancer = new CharacterData();
        //w_chronomancer.role = new w_Chronomancer();
        //w_chronomancer.name = "Chronomancer";
        //w_chronomancer.description = "I Lie and Disguise. The <color=#C080FF>toaster</color> couldn't figure out how to get my ability working.";
        //w_chronomancer.flavorText = "\"Oh, how the time flies by... or does it?\"";
        //w_chronomancer.hints = "";
        //w_chronomancer.ifLies = "";
        //w_chronomancer.picking = false;
        //w_chronomancer.startingAlignment = EAlignment.Evil;
        //w_chronomancer.type = ECharacterType.Minion;
        //w_chronomancer.bluffable = false;
        //w_chronomancer.characterId = "Chronomancer_WING";
        //w_chronomancer.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_chronomancer.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_chronomancer.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_chronomancer.color = new Color(0.8510f, 0.4549f, 0.0f);

        //CharacterData w_cardshark = new CharacterData();
        //w_cardshark.role = new w_Cardshark();
        //w_cardshark.name = "Cardshark";
        //w_cardshark.description = "<b>Game Start:</b>\nAll Minions are in the Deck.\n\nI Lie and Disguise.";
        //w_cardshark.flavorText = "\"Her sleight of hand got her accused of being a witch once.\nClose, but not quite.\"";
        //w_cardshark.hints = "";
        //w_cardshark.ifLies = "";
        //w_cardshark.picking = false;
        //w_cardshark.startingAlignment = EAlignment.Evil;
        //w_cardshark.type = ECharacterType.Minion;
        //w_cardshark.bluffable = false;
        //w_cardshark.characterId = "Cardshark_WING";
        //w_cardshark.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_cardshark.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_cardshark.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_cardshark.color = new Color(0.8510f, 0.4549f, 0.0f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_cardshark);

        CharacterData w_acolyte = new CharacterData();
        w_acolyte.role = new w_Acolyte();
        w_acolyte.name = "Acolyte";
        w_acolyte.description = "I am an Evil created by another character's ability.\nI Lie and Disguise as an out-of-play character unless stated otherwise.";
        w_acolyte.flavorText = "\"If you ask the Acolytes, the Demons are the good guys.\nThey really aren't.\"";
        w_acolyte.hints = "";
        w_acolyte.ifLies = "";
        w_acolyte.picking = false;
        w_acolyte.startingAlignment = EAlignment.Evil;
        w_acolyte.type = ECharacterType.Minion;
        w_acolyte.bluffable = false;
        w_acolyte.characterId = "Acolyte_WING";
        w_acolyte.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_acolyte.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_acolyte.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_acolyte.color = new Color(0.8510f, 0.4549f, 0.0f);
        Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_acolyte);

        CharacterData w_legion = new CharacterData();
        w_legion.role = new w_Legion();
        w_legion.name = "Agmeres"; // Name derived from Latin 'Agmen' meaning 'Army' and 'Plures' meaning 'Outnumber'.
        w_legion.description = "<b>Game Start:</b>\nMost characters are Minions.\nYou have 2 less Max Health.\n\n<b>At Night:</b>\nDeal 2 damage to you. Lose 2 Max Health.\n\nLose if all Good characters die, even if I'm dead.\n\nI Lie and Disguise.";
        w_legion.flavorText = "\"They are the chill wind on a winter's day. They are the shadow in the moonless night. They are the poison in your tea and the whisper in your ear. They are everywhere.\"";
        w_legion.hints = "Outside of Endless, I do not turn most characters into Minions, but I still cut down your max health as the nights go on.";
        w_legion.ifLies = "";
        w_legion.picking = false;
        w_legion.startingAlignment = EAlignment.Evil;
        w_legion.type = ECharacterType.Demon;
        w_legion.bluffable = false;
        w_legion.characterId = "Legion_WING";
        w_legion.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_legion.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_legion.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_legion.color = new Color(1f, 0.3804f, 0.3804f);

        CharacterData w_praesect = new CharacterData();
        w_praesect.role = new w_Praesect();
        w_praesect.name = "Praesect"; // Name derived from Latin "praefectus" meaning "officer" and "sectator" meaning "follower"
        w_praesect.description = "<b>Game Start:</b>\n2 Good Villagers become <color=#FF9999>Acolytes</color>.\n\nI Lie and Disguise.";
        w_praesect.flavorText = "\"Nobody knows if its acolytes are hypnotised, or if they're just morons.\"";
        w_praesect.hints = "";
        w_praesect.ifLies = "";
        w_praesect.picking = false;
        w_praesect.startingAlignment = EAlignment.Evil;
        w_praesect.type = ECharacterType.Demon;
        w_praesect.bluffable = false;
        w_praesect.characterId = "Praesect_WING";
        w_praesect.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_praesect.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_praesect.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_praesect.color = new Color(1f, 0.3804f, 0.3804f);
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_praesect);

        CharacterData w_twindemon = new CharacterData();
        w_twindemon.role = new w_TwinDemon();
        w_twindemon.name = "Veniyon";
        w_twindemon.description = "<b>Game Start:</b>\n<color=#d88c8b>Vidiyon</color> is in-play.\n\nWe Lie and Disguise.\nI Disguise like a Minion.";
        w_twindemon.flavorText = "\"Minion and Twin Minion's older siblings.\nThe younger twins see their siblings as role models.\"";
        w_twindemon.hints = "TRIVIA:\nUsed to be called 'Twin Demon'.\nThen, she and her brother were renamed to Hellspawn and Twin Hellspawn, before eventually being renamed again.";
        w_twindemon.ifLies = "";
        w_twindemon.picking = false;
        w_twindemon.startingAlignment = EAlignment.Evil;
        w_twindemon.type = ECharacterType.Demon;
        w_twindemon.bluffable = false;
        w_twindemon.characterId = "TwinDemon_WING";
        w_twindemon.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_twindemon.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_twindemon.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_twindemon.color = new Color(1f, 0.3804f, 0.3804f);
        nightPhase.nightCharactersOrder.Add(w_twindemon);

        CharacterData w_twindemontwin = new CharacterData();
        w_twindemontwin.role = new w_TwinDemonTwin();
        w_twindemontwin.name = "Vidiyon";
        w_twindemontwin.description = "<b>Game Start:</b>\nReduce your Max Health by 2.\n\nWe Lie and Disguise.";
        w_twindemontwin.flavorText = "\"Claims to be independent.\nHis twin sister doesn't believe him.\"";
        w_twindemontwin.hints = "TRIVIA:\nWasn't originally planned to have a unique ability.\nHe has no horns due to a birth defect. He likes it, it means he can fit through doors and blend in more easily.";
        w_twindemontwin.ifLies = "";
        w_twindemontwin.picking = false;
        w_twindemontwin.startingAlignment = EAlignment.Evil;
        w_twindemontwin.type = ECharacterType.Demon;
        w_twindemontwin.bluffable = false;
        w_twindemontwin.characterId = "TwinDemonTwin_WING";
        w_twindemontwin.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_twindemontwin.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_twindemontwin.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_twindemontwin.color = new Color(1f, 0.3804f, 0.3804f);
        var w_twinDemonTwinCharacter = ProjectContext.Instance.gameData.GetCharacterDataOfId("TwinDemonTwin_WING");
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_twindemontwin);
        Characters.Instance.startGameActOrder = insertAfterAct("Chancellor", w_twindemon);

        CharacterData w_twindemontriplet = new CharacterData();
        w_twindemontriplet.role = new w_TwinDemonThree();
        w_twindemontriplet.name = "Viciyon";
        w_twindemontriplet.description = "<b>At Night:</b>\nDeal 1 damage to you.\n\nWe Lie and Disguise.";
        w_twindemontriplet.flavorText = "\"The eldest of the Hellspawn.\nShe doesn't like to associate with her siblings.\"";
        w_twindemontriplet.hints = "I can only be in-play if both <color=#FF9999>Veniyon</color> and <color=#FF9999>Viciyon</color> are too.\n\nTRIVIA:\nUsed to be called 'Triplet Hellspawn' before being renamed alongside the other two.\nWas created when <color=#C080FF>Wingidon</color> saw <color=#FF9999>Summoner</color> (a character from a different mod) copy <color=#FF9999>Veniyon</color>'s ability, creating two instances of <color=#d88c8b>Vidiyon</color>.";
        w_twindemontriplet.ifLies = "";
        w_twindemontriplet.picking = false;
        w_twindemontriplet.startingAlignment = EAlignment.Evil;
        w_twindemontriplet.type = ECharacterType.Demon;
        w_twindemontriplet.bluffable = false;
        w_twindemontriplet.characterId = "TwinDemonTriplet_WING";
        w_twindemontriplet.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_twindemontriplet.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_twindemontriplet.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_twindemontriplet.color = new Color(1f, 0.3804f, 0.3804f);
        var w_twinDemonTwinCharacter2 = ProjectContext.Instance.gameData.GetCharacterDataOfId("TwinDemonTriplet_WING");
        nightPhase.nightCharactersOrder.Add(w_twindemontriplet);

        CharacterData w_illusionist = new CharacterData(); // Tries to convert Outcasts somehow for some reason?? Need to find out why and fix it.
        w_illusionist.role = new w_Illusionist();
        w_illusionist.name = "Emenverax"; // Name derived from Latin "ementior" meaning 'Feign' and 'Verax' meaning 'True'. Was once planned to be named "Emenumbra", deriving the second half from "Umbra" meaning shadow, darkness, etc.
        w_illusionist.description = "1 Good Villager Disguises as <color=#FF9999>Emenverax</color>.\nTake 3 extra damage if you Execute them.";
        w_illusionist.flavorText = "\"Everyone hates them, but nobody is sure who to hate.\"";
        w_illusionist.hints = "I add 3 fake Villagers and 1 fake Minion to the Deck to compensate for how loud I am.\n\nIf the <color=#C080FF>Baker</color> converts the character I cast my illusion over, my illusion is shattered.\n<i>I do not know <b>what</b> is up with that woman's power, but she scares me.</i>";
        w_illusionist.ifLies = "";
        w_illusionist.picking = false;
        w_illusionist.startingAlignment = EAlignment.Evil;
        w_illusionist.type = ECharacterType.Demon;
        w_illusionist.bluffable = false;
        w_illusionist.characterId = "Illusionist_WING";
        w_illusionist.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_illusionist.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_illusionist.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_illusionist.color = new Color(1f, 0.3804f, 0.3804f);
        Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_illusionist);
        Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_legion);
        nightPhase.nightCharactersOrder.Add(w_legion);

        CharacterData w_caedoc = new CharacterData();
        w_caedoc.role = new w_Caedoccidere();
        w_caedoc.name = "Caedoccidere"; // Name derived from Latin 'caedes' (meaning "slaughter) and 'occidere' (meaning "to kill")
        w_caedoc.description = "<b>At Night:</b>\nKill 1 Revealed character.\nDeal 3 damage to you.\n\nI Lie and Disguise.";
        w_caedoc.flavorText = "\"Most demons wait until they have enough power to destroy the entire town at once.\nThis one doesn't.\"";
        w_caedoc.hints = "Like <color=#FF9999>Lilis</color>, I prioritise killing Good characters if possible, and will not attack myself if I am somehow my only valid target.";
        w_caedoc.ifLies = "";
        w_caedoc.picking = false;
        w_caedoc.startingAlignment = EAlignment.Evil;
        w_caedoc.type = ECharacterType.Demon;
        w_caedoc.bluffable = false;
        w_caedoc.characterId = "Caedoccidere_WING";
        w_caedoc.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_caedoc.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_caedoc.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_caedoc.color = new Color(1f, 0.3804f, 0.3804f);
        nightPhase.nightCharactersOrder.Add(w_caedoc);

        CharacterData w_invertDemon = new CharacterData();
        w_invertDemon.role = new w_InvertDemon();
        w_invertDemon.name = "Mendaverte"; // Name derived from Latin "Mendacium", meaning "Lie", and "Subvertere" meaning "Subvert"
        w_invertDemon.description = "Good Villagers are Corrupted.\nEvil characters tell the truth.\nI Disguise.";
        w_invertDemon.flavorText = "You and your so-called Good and Evil...\nSuch arbitrary divisors, is it really that black-and-white to you?"; //Used to be: "\"You and your 'Good' and 'Evil', like that Plague Doctor is pure Good but the Poisoner is pure Evil.\nIs it really so black-and-white to you?\"";
        w_invertDemon.hints = "Characters I Corrupt Register as affected by Evil.\nEvils who tell the truth due to my ability do not.";
        w_invertDemon.ifLies = "";
        w_invertDemon.picking = false;
        w_invertDemon.startingAlignment = EAlignment.Evil;
        w_invertDemon.type = ECharacterType.Demon;
        w_invertDemon.bluffable = false;
        w_invertDemon.characterId = "Mendaverte_WING";
        w_invertDemon.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_invertDemon.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_invertDemon.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_invertDemon.color = new Color(1f, 0.3804f, 0.3804f);
        Characters.Instance.startGameActOrder = insertAfterAct("Shaman", w_invertDemon); // I'd put it after Plague Doctor so that it can be cured by Alchemist but for some reason that prevents Shaman from doing her job somehow?? I didn't know HealthyBluff had that effect.

        CharacterData w_mezepheles = new CharacterData(); // This was a Minion, but wound up being too strong. Whoops.
        w_mezepheles.role = new w_Mezepheles();
        w_mezepheles.name = "Venelum"; // Was 'Proselytiser'. New name derived from Latin "Malum" meaning Evil, and "Venenum" meaning Poison.
        w_mezepheles.description = "<b>Game Start:</b>\n1 Good Villager adjacent to me becomes Corrupted, if possible. They <i>cannot be Cured</i>.\n1 Good Corrupted character becomes Evil.\n\nI Lie and Disguise.";
        w_mezepheles.flavorText = "\"Sign this contract and it will all fall into place...\n Oh, how naive you truly are.\"";
        w_mezepheles.hints = "The character turned Evil by my ability will appear \"Misled\" when Executed.";
        w_mezepheles.ifLies = "";
        w_mezepheles.picking = false;
        w_mezepheles.startingAlignment = EAlignment.Evil;
        w_mezepheles.type = ECharacterType.Demon;
        w_mezepheles.bluffable = false;
        w_mezepheles.characterId = "Mezepheles_WING";
        w_mezepheles.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_mezepheles.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_mezepheles.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_mezepheles.color = new Color(1f, 0.3804f, 0.3804f);
        Characters.Instance.startGameActOrder = insertAfterAct("Alchemist", w_mezepheles); // This makes it uncurable by Alchemist but it might still have issues with other roles later on.

        CharacterData w_shard = new CharacterData();
        w_shard.role = new w_Shard();
        w_shard.name = "Specularus"; // Derived from Latin "Speculum" meaning "A mirror", "Celare" meaning "To conceal", and "Improsperus" meaning "Unfortunate".
        w_shard.description = "Everyone Disguises, but nobody Lies.\n\nMany out-of-play Villagers and Outcasts are added to the Deck View.";
        w_shard.flavorText = "\"A glass shard on its own doesn't mean much, but a shattered mirror...\"";
        w_shard.hints = "Good characters Register as affected by Evil.\nEvil characters do not.\n\nI override other characters' Disguise rules and force them to choose a random Good character from the Deck as their Disguise.\nRarely, a character might remain <color=#99FF99>Honest</color>.";
        w_shard.ifLies = "";
        w_shard.picking = false;
        w_shard.startingAlignment = EAlignment.Evil;
        w_shard.type = ECharacterType.Demon;
        w_shard.bluffable = false;
        w_shard.characterId = "Shard_WING";
        w_shard.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        w_shard.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        w_shard.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        w_shard.color = new Color(1f, 0.3804f, 0.3804f);
        Characters.Instance.startGameActOrder = insertAfterAct("Mendaverte", w_shard);

        //CharacterData w_fogDemon = new CharacterData();
        //w_fogDemon.role = new w_FogDemon();
        //w_fogDemon.name = "Tenecaligo"; // Name derived from Latin "Tenebrae" and "Caligo", both meaning "Darkness"
        //w_fogDemon.description = "<b>Game Start:</b>\nThere may be anywhere from 0-2 Outcasts and 1-3 Minions in-play.\nNo Minions created by me are in the Deck.\n\nI Lie and Disguise.";
        //w_fogDemon.flavorText = "\"In the looming mist, a Demon preys on the worst fear:\nthe <color=#C04040>fear of the unknown</color>.\"";
        //w_fogDemon.hints = "All Minions and Outcasts created by me register as affected by Evil to the <color=#C080FF>Witness</color>.";
        //w_fogDemon.ifLies = "";
        //w_fogDemon.picking = false;
        //w_fogDemon.startingAlignment = EAlignment.Evil;
        //w_fogDemon.type = ECharacterType.Demon;
        //w_fogDemon.bluffable = false;
        //w_fogDemon.characterId = "Tenecaligo_WING";
        //w_fogDemon.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_fogDemon.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_fogDemon.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_fogDemon.color = new Color(1f, 0.3804f, 0.3804f);
        //Characters.Instance.startGameActOrder = insertAfterAct("Baa", w_fogDemon);

        //CharacterData w_switchDemon = new CharacterData();
        //w_switchDemon.role = new w_SwitchDemon();
        //w_switchDemon.name = "Furtamu"; // Name derived from latin "Furta" meaning "Trickster" and "Mutatio" meaning "Change".
        //w_switchDemon.description = "I Lie unless both of my neighbours are Villagers.\nI Disguise.";
        //w_switchDemon.flavorText = "\"Wants nothing more than to fit in with those around it.\"";
        //w_switchDemon.hints = "Idea for this one was by @sequest on Discord.";
        //w_switchDemon.ifLies = "";
        //w_switchDemon.picking = false;
        //w_switchDemon.startingAlignment = EAlignment.Evil;
        //w_switchDemon.type = ECharacterType.Demon;
        //w_switchDemon.bluffable = false;
        //w_switchDemon.characterId = "Furtamu_WING";
        //w_switchDemon.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_switchDemon.cardBgColor = new Color(0.0941f, 0.0431f, 0.0431f);
        //w_switchDemon.cardBorderColor = new Color(0.8196f, 0.0f, 0.0275f);
        //w_switchDemon.color = new Color(1f, 0.3804f, 0.3804f);

        //CharacterData w_spy = new CharacterData();
        //w_spy.role = new w_Spy();
        //w_spy.name = "Spy";
        //w_spy.description = "Learn an Evil role that has not been Revealed yet, or that all have been.";
        //w_spy.flavorText = "\"Thinks he's extremely stealthy. He's not.\"";
        //w_spy.hints = "";
        //w_spy.ifLies = "";
        //w_spy.picking = false;
        //w_spy.startingAlignment = EAlignment.Good;
        //w_spy.type = ECharacterType.Villager;
        //w_spy.bluffable = true;
        //w_spy.characterId = "Spy_WING";
        //w_spy.artBgColor = new Color(0.111f, 0.0833f, 0.1415f);
        //w_spy.cardBgColor = new Color(0.26f, 0.1519f, 0.3396f);
        //w_spy.cardBorderColor = new Color(0.7133f, 0.339f, 0.8679f);
        //w_spy.color = new Color(1f, 0.935f, 0.7302f);

























































        Il2CppSystem.Collections.Generic.List<CharacterData> emptyCharacterDataList = new Il2CppSystem.Collections.Generic.List<CharacterData>();

        CustomScriptData legionScriptData = new CustomScriptData();
        legionScriptData.name = "Legion_1";
        ScriptInfo legionScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> legionList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        legionList.Add(w_legion);
        legionScript.mustInclude = legionList;
        legionScript.startingDemons = legionList;
        legionScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        legionScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        legionScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount legionCounter1 = new CharactersCount(5, 1, 1, 1, 2);
        legionCounter1.dTown = legionCounter1.town + 3;
        legionCounter1.dOuts = legionCounter1.outs + 1;
        CharactersCount legionCounter2 = new CharactersCount(6, 1, 1, 1, 3);
        legionCounter1.dTown = legionCounter2.town + 3;
        legionCounter2.dOuts = legionCounter2.outs + 1;
        CharactersCount legionCounter3 = new CharactersCount(7, 2, 1, 1, 3);
        legionCounter1.dTown = legionCounter3.town + 4;
        legionCounter3.dOuts = legionCounter3.outs + 1;
        CharactersCount legionCounter4 = new CharactersCount(8, 2, 1, 1, 4);
        legionCounter1.dTown = legionCounter4.town + 4;
        legionCounter4.dOuts = legionCounter4.outs + 1;
        CharactersCount legionCounter5 = new CharactersCount(9, 2, 1, 1, 5);
        legionCounter1.dTown = legionCounter5.town + 5;
        legionCounter4.dOuts = legionCounter5.outs + 1;
        CharactersCount legionCounter6 = new CharactersCount(10, 2, 1, 1, 6);
        legionCounter1.dTown = legionCounter6.town + 5;
        legionCounter4.dOuts = legionCounter6.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> legionCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        legionCounterList.Add(legionCounter1);
        legionCounterList.Add(legionCounter2);
        legionCounterList.Add(legionCounter2);
        legionCounterList.Add(legionCounter3);
        legionCounterList.Add(legionCounter3);
        legionCounterList.Add(legionCounter3);
        legionCounterList.Add(legionCounter4);
        legionCounterList.Add(legionCounter4);
        legionCounterList.Add(legionCounter4);
        legionCounterList.Add(legionCounter4);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter5);
        legionCounterList.Add(legionCounter6);
        legionCounterList.Add(legionCounter6);
        legionCounterList.Add(legionCounter6);
        legionCounterList.Add(legionCounter6);
        legionCounterList.Add(legionCounter6);
        legionCounterList.Add(legionCounter6);
        legionScript.characterCounts = legionCounterList;
        legionScriptData.scriptInfo = legionScript;




        CustomScriptData twinDemonScriptData = new CustomScriptData();
        twinDemonScriptData.name = "TwinDemon_1";
        ScriptInfo twinDemonScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> twinDemonList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        twinDemonList.Add(w_twindemon);
        twinDemonScript.mustInclude = twinDemonList;
        twinDemonScript.startingDemons = twinDemonList;
        twinDemonScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        twinDemonScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        twinDemonScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount twinDemonCounter1 = new CharactersCount(7, 4, 1, 1, 1);
        twinDemonCounter1.dOuts = twinDemonCounter1.outs + 1;
        CharactersCount twinDemonCounter2 = new CharactersCount(8, 4, 1, 2, 1);
        twinDemonCounter2.dOuts = twinDemonCounter2.outs + 1;
        CharactersCount twinDemonCounter3 = new CharactersCount(9, 5, 1, 1, 2);
        twinDemonCounter3.dOuts = twinDemonCounter3.outs + 1;
        CharactersCount twinDemonCounter4 = new CharactersCount(10, 5, 1, 2, 2);
        twinDemonCounter4.dOuts = twinDemonCounter4.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> twinDemonCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        twinDemonCounterList.Add(twinDemonCounter1);
        twinDemonCounterList.Add(twinDemonCounter2);
        twinDemonCounterList.Add(twinDemonCounter3);
        twinDemonCounterList.Add(twinDemonCounter4);
        twinDemonScript.characterCounts = twinDemonCounterList;
        twinDemonScriptData.scriptInfo = twinDemonScript;




        Il2CppSystem.Collections.Generic.List<CharacterData> illusionistJinxes = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        CustomScriptData illusionistScriptData = new CustomScriptData();
        illusionistScriptData.name = "Illusionist_1";
        ScriptInfo illusionistScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> illusionistList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        illusionistList.Add(w_illusionist);
        illusionistScript.mustInclude = illusionistList;
        illusionistScript.startingDemons = illusionistList;
        illusionistScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        illusionistScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        illusionistScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount illusionistCounter2 = new CharactersCount(8, 4, 1, 2, 1);
        illusionistCounter2.dOuts = illusionistCounter2.outs + 1;
        CharactersCount illusionistCounter3 = new CharactersCount(9, 5, 1, 1, 2);
        illusionistCounter3.dOuts = illusionistCounter3.outs + 1;
        CharactersCount illusionistCounter4 = new CharactersCount(10, 5, 1, 2, 2);
        illusionistCounter4.dOuts = illusionistCounter4.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> illusionistCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        illusionistCounterList.Add(illusionistCounter2);
        illusionistCounterList.Add(illusionistCounter3);
        illusionistCounterList.Add(illusionistCounter4);
        illusionistScript.characterCounts = illusionistCounterList;
        illusionistScriptData.scriptInfo = illusionistScript;




        Il2CppSystem.Collections.Generic.List<CharacterData> tripleDemonJinxes = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        CustomScriptData tripleDemonScriptData = new CustomScriptData();
        tripleDemonScriptData.name = "TwinDemon_2";
        ScriptInfo tripleDemonScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> tripleDemonList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        tripleDemonList.Add(w_twindemon);
        tripleDemonList.Add(w_twindemontriplet);
        tripleDemonScript.mustInclude = tripleDemonList;
        tripleDemonScript.startingDemons = tripleDemonList;
        tripleDemonScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        tripleDemonScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        tripleDemonScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        JinxCharacter(legionScript.startingTownsfolks, "Bishop_58855542");
        JinxCharacter(legionScript.startingTownsfolks, "Empress_13782227");
        JinxCharacter(legionScript.startingTownsfolks, "Oracle_07039445");
        JinxCharacter(legionScript.startingTownsfolks, "Prince_WING");
        JinxCharacter(legionScript.startingMinions, "Swarm_Good_WING");
        CharactersCount tripleDemonCounter1 = new CharactersCount(7, 4, 2, 0, 1);
        tripleDemonCounter1.dOuts = tripleDemonCounter1.outs + 1;
        CharactersCount tripleDemonCounter2 = new CharactersCount(8, 4, 2, 1, 1);
        tripleDemonCounter2.dOuts = tripleDemonCounter2.outs + 1;
        CharactersCount tripleDemonCounter3 = new CharactersCount(9, 5, 2, 1, 1);
        tripleDemonCounter3.dOuts = tripleDemonCounter3.outs + 1;
        CharactersCount tripleDemonCounter4 = new CharactersCount(10, 5, 2, 1, 2);
        tripleDemonCounter4.dOuts = tripleDemonCounter4.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> tripleDemonCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        tripleDemonCounterList.Add(tripleDemonCounter1);
        tripleDemonCounterList.Add(tripleDemonCounter2);
        tripleDemonCounterList.Add(tripleDemonCounter3);
        tripleDemonCounterList.Add(tripleDemonCounter4);
        tripleDemonScript.characterCounts = tripleDemonCounterList;
        tripleDemonScriptData.scriptInfo = tripleDemonScript;




        CustomScriptData caedoccidereScriptData = new CustomScriptData();
        caedoccidereScriptData.name = "Caedoccidere_1";
        ScriptInfo caedoccidereScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> caedoccidereList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        caedoccidereList.Add(w_caedoc);
        caedoccidereScript.mustInclude = caedoccidereList;
        caedoccidereScript.startingDemons = caedoccidereList;
        caedoccidereScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        caedoccidereScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        caedoccidereScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount caedoccidereCounter01 = new CharactersCount(7, 4, 1, 1, 1);
        caedoccidereCounter01.dOuts = caedoccidereCounter01.outs + 1;
        CharactersCount caedoccidereCounter02 = new CharactersCount(7, 4, 1, 2, 0);
        caedoccidereCounter02.dOuts = caedoccidereCounter02.outs + 1;
        CharactersCount caedoccidereCounter03 = new CharactersCount(8, 4, 1, 3, 0);
        caedoccidereCounter03.dOuts = caedoccidereCounter03.outs + 1;
        CharactersCount caedoccidereCounter04 = new CharactersCount(8, 4, 1, 2, 1);
        caedoccidereCounter04.dOuts = caedoccidereCounter04.outs + 1;
        CharactersCount caedoccidereCounter05 = new CharactersCount(8, 4, 1, 1, 2);
        caedoccidereCounter05.dOuts = caedoccidereCounter05.outs + 1;
        CharactersCount caedoccidereCounter06 = new CharactersCount(9, 5, 1, 3, 0);
        caedoccidereCounter06.dOuts = caedoccidereCounter06.outs + 1;
        CharactersCount caedoccidereCounter07 = new CharactersCount(9, 5, 1, 2, 1);
        caedoccidereCounter07.dOuts = caedoccidereCounter07.outs + 1;
        CharactersCount caedoccidereCounter08 = new CharactersCount(9, 5, 1, 1, 2);
        caedoccidereCounter08.dOuts = caedoccidereCounter08.outs + 1;
        CharactersCount caedoccidereCounter09 = new CharactersCount(10, 5, 1, 1, 3);
        caedoccidereCounter09.dOuts = caedoccidereCounter09.outs + 1;
        CharactersCount caedoccidereCounter10 = new CharactersCount(10, 5, 1, 2, 2);
        caedoccidereCounter10.dOuts = caedoccidereCounter10.outs + 1;
        CharactersCount caedoccidereCounter11 = new CharactersCount(10, 5, 1, 3, 1);
        caedoccidereCounter11.dOuts = caedoccidereCounter11.outs + 1;
        CharactersCount caedoccidereCounter12 = new CharactersCount(10, 5, 1, 4, 0);
        caedoccidereCounter12.dOuts = caedoccidereCounter12.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> caedoccidereCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        caedoccidereCounterList.Add(caedoccidereCounter01);
        caedoccidereCounterList.Add(caedoccidereCounter02);
        caedoccidereCounterList.Add(caedoccidereCounter03);
        caedoccidereCounterList.Add(caedoccidereCounter03);
        caedoccidereCounterList.Add(caedoccidereCounter04);
        caedoccidereCounterList.Add(caedoccidereCounter04);
        caedoccidereCounterList.Add(caedoccidereCounter05);
        caedoccidereCounterList.Add(caedoccidereCounter05);
        caedoccidereCounterList.Add(caedoccidereCounter05);
        caedoccidereCounterList.Add(caedoccidereCounter06);
        caedoccidereCounterList.Add(caedoccidereCounter06);
        caedoccidereCounterList.Add(caedoccidereCounter06);
        caedoccidereCounterList.Add(caedoccidereCounter07);
        caedoccidereCounterList.Add(caedoccidereCounter07);
        caedoccidereCounterList.Add(caedoccidereCounter07);
        caedoccidereCounterList.Add(caedoccidereCounter07);
        caedoccidereCounterList.Add(caedoccidereCounter08);
        caedoccidereCounterList.Add(caedoccidereCounter08);
        caedoccidereCounterList.Add(caedoccidereCounter08);
        caedoccidereCounterList.Add(caedoccidereCounter08);
        caedoccidereCounterList.Add(caedoccidereCounter09);
        caedoccidereCounterList.Add(caedoccidereCounter09);
        caedoccidereCounterList.Add(caedoccidereCounter09);
        caedoccidereCounterList.Add(caedoccidereCounter09);
        caedoccidereCounterList.Add(caedoccidereCounter09);
        caedoccidereCounterList.Add(caedoccidereCounter10);
        caedoccidereCounterList.Add(caedoccidereCounter10);
        caedoccidereCounterList.Add(caedoccidereCounter10);
        caedoccidereCounterList.Add(caedoccidereCounter10);
        caedoccidereCounterList.Add(caedoccidereCounter10);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter11);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereCounterList.Add(caedoccidereCounter12);
        caedoccidereScript.characterCounts = caedoccidereCounterList;
        caedoccidereScriptData.scriptInfo = caedoccidereScript;




        CustomScriptData praesectScriptData = new CustomScriptData();
        praesectScriptData.name = "Praesect_1";
        ScriptInfo praesectScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> praesectList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        praesectList.Add(w_praesect);
        praesectScript.mustInclude = praesectList;
        praesectScript.startingDemons = praesectList;
        praesectScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        praesectScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        praesectScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        JinxCharacter(legionScript.startingTownsfolks, "Spy_WING");
        JinxCharacter(legionScript.startingMinions, "Swarm_Good_WING");
        CharactersCount praesectCounter2 = new CharactersCount(8, 5, 1, 2, 0);
        praesectCounter2.dOuts = praesectCounter2.outs + 1;
        CharactersCount praesectCounter3 = new CharactersCount(9, 6, 1, 1, 1);
        praesectCounter3.dOuts = praesectCounter3.outs + 1;
        CharactersCount praesectCounter4 = new CharactersCount(10, 6, 1, 2, 1);
        praesectCounter4.dOuts = praesectCounter4.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> praesectCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        praesectCounterList.Add(praesectCounter2);
        praesectCounterList.Add(praesectCounter3);
        praesectCounterList.Add(praesectCounter4);
        praesectScript.characterCounts = praesectCounterList;
        praesectScriptData.scriptInfo = praesectScript;




        CustomScriptData mendaverteScriptData = new CustomScriptData();
        mendaverteScriptData.name = "Mendaverte_1";
        ScriptInfo mendaverteScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> mendaverteList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        mendaverteList.Add(w_invertDemon);
        mendaverteScript.mustInclude = mendaverteList;
        mendaverteScript.startingDemons = mendaverteList;
        mendaverteScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        mendaverteScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        mendaverteScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        JinxCharacter(legionScript.startingTownsfolks, "Alchemist_94446803");
        JinxCharacter(legionScript.startingMinions, "Turncoat_WING");
        CharactersCount mendaverteCounter2 = new CharactersCount(8, 5, 1, 1, 1);
        mendaverteCounter2.dOuts = mendaverteCounter2.outs + 1;
        CharactersCount mendaverteCounter3 = new CharactersCount(9, 5, 1, 2, 1);
        mendaverteCounter3.dOuts = mendaverteCounter3.outs + 1;
        CharactersCount mendaverteCounter4 = new CharactersCount(10, 6, 1, 1, 2);
        mendaverteCounter4.dOuts = mendaverteCounter4.outs + 1;
        CharactersCount mendaverteCounter5 = new CharactersCount(10, 5, 1, 2, 2);
        mendaverteCounter5.dOuts = mendaverteCounter5.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> mendaverteCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        mendaverteCounterList.Add(mendaverteCounter2);
        mendaverteCounterList.Add(mendaverteCounter3);
        mendaverteCounterList.Add(mendaverteCounter4);
        mendaverteCounterList.Add(mendaverteCounter5);
        mendaverteScript.characterCounts = mendaverteCounterList;
        mendaverteScriptData.scriptInfo = mendaverteScript;




        CustomScriptData venelumScriptData = new CustomScriptData();
        venelumScriptData.name = "Venelum_1";
        ScriptInfo venelumScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> venelumList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        venelumList.Add(w_mezepheles);
        venelumScript.mustInclude = venelumList;
        venelumScript.startingDemons = venelumList;
        venelumScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        venelumScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        venelumScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        CharactersCount venelumCounter1 = new CharactersCount(8, 5, 1, 1, 1);
        venelumCounter1.dOuts = venelumCounter1.outs + 1;
        CharactersCount venelumCounter2 = new CharactersCount(9, 5, 1, 2, 1);
        venelumCounter2.dOuts = venelumCounter2.outs + 1;
        CharactersCount venelumCounter3 = new CharactersCount(9, 5, 1, 1, 2);
        venelumCounter3.dOuts = venelumCounter3.outs + 1;
        CharactersCount venelumCounter4 = new CharactersCount(10, 6, 1, 1, 2);
        venelumCounter4.dOuts = venelumCounter4.outs + 1;
        CharactersCount venelumCounter5 = new CharactersCount(10, 5, 1, 2, 2);
        venelumCounter5.dOuts = venelumCounter5.outs + 1;
        Il2CppSystem.Collections.Generic.List<CharactersCount> venelumCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        venelumCounterList.Add(venelumCounter1);
        venelumCounterList.Add(venelumCounter2);
        venelumCounterList.Add(venelumCounter3);
        venelumCounterList.Add(venelumCounter4);
        venelumCounterList.Add(venelumCounter5);
        venelumScript.characterCounts = venelumCounterList;
        venelumScriptData.scriptInfo = venelumScript;




        CustomScriptData shardScriptData = new CustomScriptData();
        shardScriptData.name = "Shard_1";
        ScriptInfo shardScript = new ScriptInfo();
        Il2CppSystem.Collections.Generic.List<CharacterData> shardList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        shardList.Add(w_shard);
        shardScript.mustInclude = shardList;
        shardScript.startingDemons = shardList;
        shardScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        shardScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        shardScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        JinxCharacter(shardScript.startingTownsfolks, "Prince_WING");
        CharactersCount shardCounter1 = new CharactersCount(7, 5, 1, 0, 1);
        shardCounter1.dTown = 10;
        shardCounter1.dOuts = 4;
        CharactersCount shardCounter2 = new CharactersCount(7, 4, 1, 1, 1);
        shardCounter2.dTown = 10;
        shardCounter2.dOuts = 4;
        CharactersCount shardCounter3 = new CharactersCount(8, 5, 1, 1, 1);
        shardCounter3.dTown = 11;
        shardCounter3.dOuts = 5;
        CharactersCount shardCounter4 = new CharactersCount(8, 4, 1, 2, 1);
        shardCounter4.dTown = 11;
        shardCounter4.dOuts = 5;
        CharactersCount shardCounter5 = new CharactersCount(8, 4, 1, 1, 2);
        shardCounter5.dTown = 11;
        shardCounter5.dOuts = 5;
        CharactersCount shardCounter6 = new CharactersCount(8, 5, 1, 0, 2);
        shardCounter6.dTown = 11;
        shardCounter6.dOuts = 5;
        CharactersCount shardCounter7 = new CharactersCount(9, 5, 1, 1, 2);
        shardCounter7.dTown = 12;
        shardCounter7.dOuts = 6;
        CharactersCount shardCounter8 = new CharactersCount(9, 5, 1, 2, 1);
        shardCounter8.dTown = 12;
        shardCounter8.dOuts = 6;
        CharactersCount shardCounter9 = new CharactersCount(10, 5, 1, 2, 2);
        shardCounter9.dTown = 13;
        shardCounter9.dOuts = 7;
        CharactersCount shardCounter10 = new CharactersCount(10, 6, 1, 0, 3);
        shardCounter10.dTown = 13;
        shardCounter10.dOuts = 7;
        Il2CppSystem.Collections.Generic.List<CharactersCount> shardCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        shardCounterList.Add(shardCounter1);
        shardCounterList.Add(shardCounter2);
        shardCounterList.Add(shardCounter3);
        shardCounterList.Add(shardCounter4);
        shardCounterList.Add(shardCounter5);
        shardCounterList.Add(shardCounter6);
        shardCounterList.Add(shardCounter7);
        shardCounterList.Add(shardCounter8);
        shardCounterList.Add(shardCounter9);
        shardCounterList.Add(shardCounter10);
        shardScript.characterCounts = shardCounterList;
        shardScriptData.scriptInfo = shardScript;




        //CustomScriptData tenecaligoScriptData = new CustomScriptData();
        //tenecaligoScriptData.name = "Tenecaligo_1";
        //ScriptInfo tenecaligoScript = new ScriptInfo();
        //Il2CppSystem.Collections.Generic.List<CharacterData> tenecaligoList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        //tenecaligoList.Add(w_fogDemon);
        //tenecaligoScript.mustInclude = tenecaligoList;
        //tenecaligoScript.startingDemons = tenecaligoList;
        //tenecaligoScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        //tenecaligoScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        //tenecaligoScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        //CharactersCount tenecaligoCounter2 = new CharactersCount(10, 9, 1, 0, 0);
        //tenecaligoCounter2.dOuts = 4;
        //Il2CppSystem.Collections.Generic.List<CharactersCount> tenecaligoCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        //tenecaligoCounterList.Add(tenecaligoCounter2);
        //tenecaligoScript.characterCounts = tenecaligoCounterList;
        //tenecaligoScriptData.scriptInfo = tenecaligoScript;




        //CustomScriptData furtamuScriptData = new CustomScriptData();
        //furtamuScriptData.name = "Furtamu_1";
        //ScriptInfo furtamuScript = new ScriptInfo();
        //Il2CppSystem.Collections.Generic.List<CharacterData> furtamuList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        //furtamuList.Add(w_switchDemon);
        //furtamuScript.mustInclude = furtamuList;
        //furtamuScript.startingDemons = furtamuList;
        //furtamuScript.startingTownsfolks = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingTownsfolks;
        //furtamuScript.startingOutsiders = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingOutsiders;
        //furtamuScript.startingMinions = ProjectContext.Instance.gameData.advancedAscension.possibleScriptsData[0].scriptInfo.startingMinions;
        //CharactersCount furtamuCounter1 = new CharactersCount(8, 5, 1, 1, 1);
        //furtamuCounter1.dOuts = furtamuCounter1.outs + 1;
        //CharactersCount furtamuCounter2 = new CharactersCount(9, 5, 1, 2, 1);
        //furtamuCounter2.dOuts = furtamuCounter2.outs + 1;
        //CharactersCount furtamuCounter3 = new CharactersCount(10, 6, 1, 1, 2);
        //furtamuCounter3.dOuts = furtamuCounter3.outs + 1;
        //Il2CppSystem.Collections.Generic.List<CharactersCount> furtamuCounterList = new Il2CppSystem.Collections.Generic.List<CharactersCount>();
        //furtamuCounterList.Add(furtamuCounter1);
        //furtamuCounterList.Add(furtamuCounter2);
        //furtamuCounterList.Add(furtamuCounter3);
        //furtamuScript.characterCounts = furtamuCounterList;
        //furtamuScriptData.scriptInfo = furtamuScript;

        //List<CharacterData> strangeDisguisesChars = new List<CharacterData>();
        //addCharacterDataToList("Clairvoyant_WING", strangeDisguisesChars);
        //addCharacterDataToList("Cleric_EP", strangeDisguisesChars);
        //addCharacterDataToList("Confessor_18741708", strangeDisguisesChars);
        //addCharacterDataToList("Detective_VP", strangeDisguisesChars);
        //addCharacterDataToList("Dreamer_32014895", strangeDisguisesChars);
        //addCharacterDataToList("Druid_89845092", strangeDisguisesChars);
        //addCharacterDataToList("Empress_13782227", strangeDisguisesChars);
        //addCharacterDataToList("Forager_WING", strangeDisguisesChars);
        //addCharacterDataToList("Lookout_41018246", strangeDisguisesChars);
        //addCharacterDataToList("Oracle_07039445", strangeDisguisesChars);
        //addCharacterDataToList("Prince_WING", strangeDisguisesChars);
        //addCharacterDataToList("Scout_88081716", strangeDisguisesChars);
        //addCharacterDataToList("Sentinel_WING", strangeDisguisesChars);
        //addCharacterDataToList("Village Idiot_VP", strangeDisguisesChars);
        //addCharacterDataToList("Witness_25155076", strangeDisguisesChars);
        //addCharacterDataToList("Doppleganger_52694042", strangeDisguisesChars);
        //addCharacterDataToList("Drunk_15369527", strangeDisguisesChars);
        //addCharacterDataToList("GoodTwin_VP", strangeDisguisesChars);
        //addCharacterDataToList("Lunatic_WING", strangeDisguisesChars);
        //addCharacterDataToList("Mayor_VP", strangeDisguisesChars);
        //addCharacterDataToList("Lycaon_VP", strangeDisguisesChars);
        //addCharacterDataToList("Shaman_26945607", strangeDisguisesChars);
        //addCharacterDataToList("Swarm_Good_WING", strangeDisguisesChars);
        //addCharacterDataToList("Turncoat_WING", strangeDisguisesChars);
        //addCharacterDataToList("Belias_EP", strangeDisguisesChars);
        //addCharacterDataToList("Illusionist_WING", strangeDisguisesChars);
        //addCharacterDataToList("TwinDemon_WING", strangeDisguisesChars);
        //replaceScriptChars(strangeDisguisesChars, strangeDisguisesScriptData);
        //Il2CppReferenceArray<CharacterData> advancedAscensionDemons = new Il2CppReferenceArray<CharacterData>(advancedAscension.demons.Length + 2);
        //advancedAscensionDemons = advancedAscension.demons;
        //advancedAscensionDemons[advancedAscensionDemons.Length - 2] = w_legion;
        //advancedAscensionDemons[advancedAscensionDemons.Length - 1] = w_twindemon;
        //advancedAscension.demons = advancedAscensionDemons;
        //Il2CppReferenceArray<CharacterData> advancedAscensionStartingDemons = new Il2CppReferenceArray<CharacterData>(advancedAscension.startingDemons.Length + 2);
        //advancedAscensionStartingDemons = advancedAscension.startingDemons;
        //advancedAscensionStartingDemons[advancedAscensionStartingDemons.Length - 2] = w_legion;
        //advancedAscensionStartingDemons[advancedAscensionStartingDemons.Length - 1] = w_twindemon;
        //advancedAscension.startingDemons = advancedAscensionStartingDemons;
        //Il2CppReferenceArray<CustomScriptData> advancedAscensionScriptsData = new Il2CppReferenceArray<CustomScriptData>(advancedAscension.possibleScriptsData.Length + 2);
        //advancedAscensionScriptsData = advancedAscension.possibleScriptsData;
        //advancedAscensionScriptsData[advancedAscensionScriptsData.Length - 2] = legionScriptData;
        //advancedAscensionScriptsData[advancedAscensionScriptsData.Length - 1] = twinDemonScriptData;
        //advancedAscension.possibleScriptsData = advancedAscensionScriptsData;
        AscensionsData advancedAscension = ProjectContext.Instance.gameData.advancedAscension;
        w_addDemonRole(advancedAscension, w_legion, "Baa_Difficult", "Legion_1", legionScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_1", twinDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_illusionist, "Baa_Difficult", "Illusionist_1", illusionistScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_2", tripleDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_caedoc, "Baa_Difficult", "Caedoccidere_1", caedoccidereScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_praesect, "Baa_Difficult", "Praesect_1", praesectScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_invertDemon, "Baa_Difficult", "Mendaverte_1", mendaverteScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_mezepheles, "Baa_Difficult", "Venelum_1", venelumScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_shard, "Baa_Difficult", "Shard_1", shardScriptData, emptyCharacterDataList);





        w_addDemonRole(advancedAscension, w_legion, "Baa_Difficult", "Legion_1", legionScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_1", twinDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_illusionist, "Baa_Difficult", "Illusionist_1", illusionistScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_2", tripleDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_caedoc, "Baa_Difficult", "Caedoccidere_1", caedoccidereScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_praesect, "Baa_Difficult", "Praesect_1", praesectScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_invertDemon, "Baa_Difficult", "Mendaverte_1", mendaverteScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_mezepheles, "Baa_Difficult", "Venelum_1", venelumScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_shard, "Baa_Difficult", "Shard_1", shardScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_legion, "Baa_Difficult", "Legion_1", legionScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_1", twinDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_illusionist, "Baa_Difficult", "Illusionist_1", illusionistScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_twindemon, "Baa_Difficult", "TwinDemon_2", tripleDemonScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_caedoc, "Baa_Difficult", "Caedoccidere_1", caedoccidereScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_praesect, "Baa_Difficult", "Praesect_1", praesectScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_invertDemon, "Baa_Difficult", "Mendaverte_1", mendaverteScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_mezepheles, "Baa_Difficult", "Venelum_1", venelumScriptData, emptyCharacterDataList);
        w_addDemonRole(advancedAscension, w_shard, "Baa_Difficult", "Shard_1", shardScriptData, emptyCharacterDataList);


        foreach (CustomScriptData scriptData in advancedAscension.possibleScriptsData)
        {
            ScriptInfo script = scriptData.scriptInfo;
            addRole(script.startingTownsfolks, w_arithmetician);
            addRole(script.startingTownsfolks, w_chiromancer);
            addRole(script.startingTownsfolks, w_clairvoyant);
            addRole(script.startingTownsfolks, w_devout);
            addRole(script.startingTownsfolks, w_forager);
            addRole(script.startingTownsfolks, w_gambler);
            addRole(script.startingTownsfolks, w_introvert);
            addRole(script.startingTownsfolks, w_lamb);
            addRole(script.startingTownsfolks, w_performer);
            addRole(script.startingTownsfolks, w_prince);
            addRole(script.startingTownsfolks, w_scavenger);
            addRole(script.startingTownsfolks, w_sentinel);
            addRole(script.startingTownsfolks, w_spy);
            addRole(script.startingTownsfolks, w_slayerRework);
            addRole(script.startingOutsiders, w_lunatic);
            addRole(script.startingOutsiders, w_marionette);
            //addRole(script.startingOutsiders, w_occultist);
            addRole(script.startingOutsiders, w_revolutionary);
            addRole(script.startingMinions, w_professional);
            //addRole(script.startingMinions, w_saboteur);
            addRole(script.startingMinions, w_swarm_good);
            addRole(script.startingMinions, w_turncoat);
            addRole(script.startingMinions, w_undying);
            for (int i = 0; i < allDatas.Length; i++)
            {
                //if (allDatas[i].characterId == "Gambler_42592744")
                //{
                //    script.startingTownsfolks.Remove(allDatas[i]);
                //}
            }
        }
        foreach (CustomScriptData scriptData in advancedAscension.possibleScriptsData)
        {
            Il2CppSystem.Collections.Generic.List<string> JinxList = new Il2CppSystem.Collections.Generic.List<string>();
            JinxList.Add("Bishop_58855542");
            JinxList.Add("Empress_13782227");
            JinxList.Add("Oracle_07039445");
            JinxList.Add("Prince_WING");
            JinxList.Add("Doppleganger_52694042");
            JinxList.Add("Baron_04539999");
            JinxList.Add("Mezepheles_09511163");
            JinxList.Add("Shaman_26945607");
            JinxList.Add("Swarm_Good_WING");
            JinxList.Add("Toxomancer_WING");
            if (scriptData.name.ToString() == "Legion_1")
            {
                for (int i = 0; i < legionScript.startingTownsfolks.Count; i++)
                {
                    if (JinxList.Contains(legionScript.startingTownsfolks[i].characterId))
                    {
                        i -= 1;
                        legionScript.startingTownsfolks.RemoveAt(i);
                    }
                }
                for (int i = 0; i < legionScript.startingOutsiders.Count; i++)
                {
                    if (JinxList.Contains(legionScript.startingOutsiders[i].characterId))
                    {
                        i -= 1;
                        legionScript.startingOutsiders.RemoveAt(i);
                    }
                }
                for (int i = 0; i < legionScript.startingMinions.Count; i++)
                {
                    if (JinxList.Contains(legionScript.startingMinions[i].characterId))
                    {
                        i -= 1;
                        legionScript.startingMinions.RemoveAt(i);
                    }
                }
            }
        }


        for (int j = 0; j < advancedAscension.possibleScriptsData.Length; j++)
        {
            Debug.LogWarning(advancedAscension.possibleScriptsData[j].name);
        }
        //w_addDemonRole(advancedAscension, w_switchDemon, "Baa_Difficult", "Furtamu_1", furtamuScriptData);
    }
    // By the vanilla rule of one demon per village.
    public void w_addDemonRole(AscensionsData advancedAscension, CharacterData? data, string oldScriptName, string newScriptName, CustomScriptData w_NewScript, Il2CppSystem.Collections.Generic.List<CharacterData> jinxList, int weight = 1)
    {
        if (data == null)
        {
            return;
        }
        foreach (CustomScriptData scriptData in advancedAscension.possibleScriptsData)
        {
            if (scriptData.name == oldScriptName)
            {
                CustomScriptData newScriptData = GameObject.Instantiate(scriptData);
                newScriptData.name = newScriptName;
                ScriptInfo newScript = new ScriptInfo();
                ScriptInfo script = w_NewScript.scriptInfo;
                newScriptData.scriptInfo = newScript;
                newScript.startingTownsfolks = script.startingTownsfolks;
                newScript.startingOutsiders = script.startingOutsiders;
                newScript.startingMinions = script.startingMinions;
                newScript.startingDemons = script.startingDemons;
                newScript.characterCounts = w_NewScript.scriptInfo.characterCounts;
                //newScript.startingDemons = new Il2CppSystem.Collections.Generic.List<CharacterData>();
                //newScript.startingDemons.Add(data);
                var newPSD = advancedAscension.possibleScriptsData.Append(newScriptData);
                for (int i = 0; i < weight - 1; i++)
                {
                    newPSD = newPSD.Append(newScriptData);
                }
                advancedAscension.possibleScriptsData = newPSD.ToArray();
                return;
            }
        }
    }
    public void addCharacterDataToList(string ID, List<CharacterData> Characters)
    {
        foreach (CharacterData targetChar in Gameplay.Instance.GetAllAscensionCharacters())
        {
            if (targetChar.characterId == ID)
            {
                Characters.Append(targetChar);
            }
        }
    }
    public void replaceScriptChars(List<CharacterData> Characters, CustomScriptData w_TargetScript)
    {
        w_TargetScript.scriptInfo.startingTownsfolks.Clear();
        w_TargetScript.scriptInfo.startingOutsiders.Clear();
        w_TargetScript.scriptInfo.startingMinions.Clear();
        w_TargetScript.scriptInfo.startingDemons.Clear();
        foreach (CharacterData targetChar in Characters)
        {
            if (targetChar.type == ECharacterType.Villager)
            {
                w_TargetScript.scriptInfo.startingTownsfolks.Add(targetChar);
            }
            if (targetChar.type == ECharacterType.Outcast)
            {
                w_TargetScript.scriptInfo.startingOutsiders.Add(targetChar);
            }
            if (targetChar.type == ECharacterType.Minion)
            {
                w_TargetScript.scriptInfo.startingMinions.Add(targetChar);
            }
            if (targetChar.type == ECharacterType.Demon)
            {
                w_TargetScript.scriptInfo.startingDemons.Add(targetChar);
            }
        }
    }
    public void addRole(Il2CppSystem.Collections.Generic.List<CharacterData> list, CharacterData data)
    {
        if (list.Contains(data))
        {
            return;
        }
        list.Add(data);
    }
    public CharacterData[] allDatas = System.Array.Empty<CharacterData>();
    public override void OnUpdate()
    {
        if (allDatas.Length == 0)
        {
            var loadedCharList = Resources.FindObjectsOfTypeAll(Il2CppType.Of<CharacterData>());
            if (loadedCharList != null)
            {
                allDatas = new CharacterData[loadedCharList.Length];
                for (int i = 0; i < loadedCharList.Length; i++)
                {
                    allDatas[i] = loadedCharList[i]!.Cast<CharacterData>();
                }
            }
        }
    }
    public CharacterData[] insertAfterAct(string previous, CharacterData data)
    {
        CharacterData[] actList = Characters.Instance.startGameActOrder;
        int actSize = actList.Length;
        CharacterData[] newActList = new CharacterData[actSize + 1];
        bool inserted = false;
        for (int i = 0; i < actSize; i++)
        {
            if (inserted)
            {
                newActList[i + 1] = actList[i];
            }
            else
            {
                newActList[i] = actList[i];
                if (actList[i].name == previous)
                {
                    newActList[i + 1] = data;
                    inserted = true;
                }
            }
        }
        if (!inserted)
        {
            LoggerInstance.Msg("");
        }
        return newActList;
    }
    public CharacterData[] insertBeforeAct(string next, CharacterData data)
    {
        CharacterData[] actList = Characters.Instance.startGameActOrder;
        Il2CppSystem.Collections.Generic.List<CharacterData> newActList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        bool added = false;
        foreach (CharacterData character in actList)
        {
            if (character.name.ToString() == next && added == false)
            {
                newActList.Add(data);
            }
            newActList.Add(character);
        }
        CharacterData[] newActArray = new CharacterData[actList.Length + 1];
        int counter = 0;
        foreach (CharacterData character in newActList)
        {
            Debug.Log(string.Format("Adding {0} to act order at array position {1}", character.name.ToString(), counter));
            newActArray[counter] = character;
            counter += 1;
        }
        return newActArray;
    }
    public static Il2CppSystem.Collections.Generic.List<CharacterData> JinxCharacter(Il2CppSystem.Collections.Generic.List<CharacterData> inputList, string ID)
    {
        Il2CppSystem.Collections.Generic.List<CharacterData> outputList = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        foreach (CharacterData character in inputList)
        {
            if (character.characterId != ID)
            {
                outputList.Add(character);
            }
        }
        return outputList;
    }

    public static class HiddenRoleStatus
    {
        public static ECharacterStatus hiddenRole = (ECharacterStatus)999;
    }

    //int toxomancerPoisonTimer = 0;
    //int toxomancerDeathTimer = 0;


    /*private void OnCharacterRevealed(Character revealed)
    {
        toxomancerPoisonTimer -= 1;
        toxomancerDeathTimer -= 1;
        CharacterData charData = revealed.dataRef;
        Il2CppSystem.Collections.Generic.List<Character> allChars = new Il2CppSystem.Collections.Generic.List<Character>(Gameplay.CurrentCharacters.Pointer);

        int revealCount = 0;
        for (int i = 0; i < allChars.Count; i++)
        {
            if (allChars[i].revealed == true)
            {
                revealCount++;
            }
        }
        if (revealCount == 1)
        {
            toxomancerPoisonTimer = 2;
            toxomancerDeathTimer = 4;
        }

        bool toxomancerInPlay = false;
        Character toxomancer = new Character();
        for (int i = 0; i < allChars.Count; i++)
        {
            if (allChars[i].dataRef.characterId == "Toxomancer_WING" && allChars[i].state != ECharacterState.Dead)
            {
                toxomancerInPlay = true;
                break;
            }
            if (allChars[i].dataRef.characterId == "Toxomancer_WING")
            {
                toxomancer = allChars[i];
            }
        }
        if (toxomancerInPlay)
        {
            if (toxomancerPoisonTimer == 0)
            {
                Il2CppSystem.Collections.Generic.List<Character> possiblePoisonTargets = new Il2CppSystem.Collections.Generic.List<Character>();
                foreach (Character character in allChars)
                {
                    if (character.GetRegisterAs().type == ECharacterType.Villager && character.GetAlignment() == EAlignment.Good && character.state != ECharacterState.Dead)
                    {
                        possiblePoisonTargets.Add(character);
                    }
                }
                Character poisonTarget = possiblePoisonTargets[UnityEngine.Random.RandomRangeInt(0, possiblePoisonTargets.Count)];
                poisonTarget.statuses.AddStatus(ECharacterStatus.Corrupted, toxomancer);
                poisonTarget.statuses.AddStatus(w_Toxomancer.ToxomancerPoison.toxomancerPoison, toxomancer);
                toxomancerPoisonTimer = 3;
                toxomancerDeathTimer = 2;
            }
        }
        if (toxomancerDeathTimer == 0)
        {
            foreach (Character character in allChars)
            {
                if (character.statuses.Contains(w_Toxomancer.ToxomancerPoison.toxomancerPoison))
                {
                    PlayerController.PlayerInfo.health.Damage(1);
                    character.RevealAllReal();
                    character.KillByDemon(toxomancer);
                }
            }
        }

    }*/




























    [HarmonyPatch(typeof(ObjectivesUI), nameof(ObjectivesUI.UpdateObjectives))]
    public static class ChangeCounter
    {
        public static void Postfix(ObjectivesUI __instance)
        {
            //bool LilisInPlay = false;
            int minions = Gameplay.CurrentScript.minion;
            int demons = Gameplay.CurrentScript.demon;
            int MaxEvils = minions + demons;
            var deadCharacters = Gameplay.DeadCharacters;
            Il2CppSystem.Collections.Generic.List<Character> allCurrentCharacters = new Il2CppSystem.Collections.Generic.List<Character>(Gameplay.CurrentCharacters.Pointer);
            Il2CppSystem.Collections.Generic.List<CharacterData> allCurrentCharactersData = new Il2CppSystem.Collections.Generic.List<CharacterData>(Gameplay.Instance.GetScriptCharacters().Pointer);
            Il2CppSystem.Collections.Generic.List<string> Evils = new();
            //Il2CppSystem.Collections.Generic.List<string> allCurrentCharactersNames;
            //Il2CppSystem.Collections.Generic.List<string> allCurrentCharactersDataNames;

            //allCurrentCharactersNames = sortByName(allCurrentCharacters);
            //allCurrentCharactersDataNames = sortByName(allCurrentCharactersData);






            int minEvilsKilled = 0;
            int maxEvilsKilled = 0;
            int AddedEvils = 0;
            //int AddedEvils1 = 0;
            //int AddedEvils2 = 0;

            foreach (var deadCharacter in deadCharacters)
            {
                if (deadCharacter.alignment == EAlignment.Evil || deadCharacter.statuses.Contains(HiddenRoleStatus.hiddenRole))
                {
                    maxEvilsKilled++;
                    if (!deadCharacter.statuses.Contains(HiddenRoleStatus.hiddenRole))
                    {
                        minEvilsKilled++;
                    }
                }
            }


            //foreach (var character in allCurrentCharacters)
            //{

                //string characterData = allCurrentCharactersData[i].name.ToString();
                //string character;

                /*if (i <= allCurrentCharacters.Count - 1)
                {
                   character = allCurrentCharactersNames[i];
                }
                else
                {
                    character = "";
                }*/
                //MelonLogger.Msg("Character: " + character.dataRef.name.ToString());

                /*if (character == "Belias" || character == "Mayor" || character == "Good Twin" || character == "Puppeteer" || character == "Hypnotist" || character == "Executioner")
                {

                    AddedEvils1++;
                }*/


                //if (character.dataRef.name == "Belias" || character.dataRef.name == "Mayor" || character.dataRef.name == "Good Twin" || character.dataRef.name == "Puppeteer" || character.dataRef.name == "Hypnotist" || character.dataRef.name == "Executioner")
                //{
                    //if (Evils.Contains(character.dataRef.name.ToString()))
                    //{
                    //    AddedEvils++;
                    //}

                    //else
                    //{
                     //   Evils.Add(character.dataRef.name.ToString());
                    //    AddedEvils++;
                    //}

                //}

            //}

            //foreach (var characterData in allCurrentCharactersData)
            //{
             //   if (characterData.name.ToString() == "Hellspawn")
            //        MaxEvils++;
            //    if (characterData.name == "Belias" || characterData.name == "Mayor" || characterData.name == "Good Twin" || characterData.name == "Puppeteer" || characterData.name == "Hypnotist" || characterData.name == "Executioner")
            //    {

            //        if (!Evils.Contains(characterData.name.ToString()))
            //        {
            //            Evils.Add(characterData.name.ToString());
            //            AddedEvils++;
            //        }
            //    }

            //}

            /*if(AddedEvils2 > AddedEvils1)
            {
                AddedEvils = AddedEvils2;
            }

            else
            {
                AddedEvils = AddedEvils1;
            }*/

            //string EvilsKilledText = EvilsKilled.ToString();
            //string MaxEvilsAmount = AddedEvils.ToString();

                //if (MaxEvils < minions + demons)
                // MaxEvils++;
            if (minEvilsKilled == maxEvilsKilled)
            {
                __instance.evilsKilled.text = System.String.Format("<color=grey>Evils killed:</color> <color=red>{0}", minEvilsKilled);
            }
            else
            {
                __instance.evilsKilled.text = System.String.Format("<color=grey>Evils killed:</color> <color=red>{0}-{1}", minEvilsKilled, maxEvilsKilled);
            }


            /* else if(MaxEvils < minions + demons)
             {
                 MaxEvilsText = System.String.Format("<color=red>{0}-{1}", MaxEvils, minions + demons);
             }*/

            //if(LilisInPlay)
            // {
            //    EvilsKilledText = "?";
            // }

            // LilisInPlay = false;

            string minionCountText = "Minions";
            if (minions == 1)
            {
                minionCountText = "Minion";
            }
            string demonCountText = "Demons";
            if (demons == 1)
            {
                demonCountText = "Demon";
            }
            __instance.objective.text = System.String.Format("Find and Execute all Evil Characters<br><color=grey><size=18>(<color=orange>{0}+ {2}</color> and <color=red>{1}+ {3} </color>)", minions, demons, minionCountText, demonCountText);

        }
    }
}