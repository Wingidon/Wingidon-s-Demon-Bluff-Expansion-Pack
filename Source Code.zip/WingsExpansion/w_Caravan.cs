﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using System.Net.Http.Headers;
using UnityEngine;
using System.Text;
using UnityEngine.UI;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Caravan : Role
{
    private Il2CppSystem.Collections.Generic.List<Character> selection = new();
    private Character random = new();
    private Character random2 = new();
    public w_Caravan() : base(ClassInjector.DerivedConstructorPointer<w_Caravan>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Caravan(System.IntPtr ptr) : base(ptr)
    {

    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            System.Collections.Generic.List<Character> newList = new System.Collections.Generic.List<Character>();
            System.Collections.Generic.List<Character> newList2 = new System.Collections.Generic.List<Character>();
            foreach (Character character in Gameplay.CurrentCharacters)
                if (!(character is Recluse))
                {
                    newList.Add(character);
                    newList2.Add(character);
                }
            random = newList[UnityEngine.Random.RandomRangeInt(0, newList.Count)];
            newList2.Remove(random);
            random2 = newList2[UnityEngine.Random.RandomRangeInt(0, newList2.Count)];
            selection.Add(random2);
            random.registerAs = random2.dataRef;
            random2.registerAs = random.dataRef;
        }
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(new ActedInfo(string.Format("I transported the {0}", random.GetRegisterAs().role.charRef.chName), selection));
        }
        if (trigger == ETriggerPhase.OnExecuted)
        {
            selection.Add(random);
            onActed.Invoke(new ActedInfo(string.Format("I transported the {0} and the {1}", random.GetRegisterAs(), random2.GetRegisterAs()), selection));
        }
    }
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("You shouldn't be seeing this.");
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        return new ActedInfo("You shouldn't be seeing this.");
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            random = characters[UnityEngine.Random.RandomRangeInt(0, characters.Count)];
            selection.Add(random);
            onActed.Invoke(new ActedInfo(string.Format("I transported the {0}", random.GetRegisterAs().role), selection));
        }
    }
    public string ConjourInfo()
    {
        return "";
    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        return null;
    }
}


