﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using static Il2CppSystem.Globalization.CultureInfo;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_TwinDemon : Demon
{
    public CharacterData[] allDatas = Il2CppSystem.Array.Empty<CharacterData>();
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            Il2CppSystem.Collections.Generic.List<Character> chars = new Il2CppSystem.Collections.Generic.List<Character>(Gameplay.CurrentCharacters.Pointer);
            Character pickedChar = new Character();
            chars = Characters.Instance.FilterCharacterType(chars, ECharacterType.Villager);
            chars = Characters.Instance.FilterAlignmentCharacters(chars, EAlignment.Good);
            if (chars.Count > 0)
            {
                pickedChar = chars[UnityEngine.Random.Range(0, chars.Count)];
                bool twinHellspawnInPlay = false;
                foreach (Character c in Gameplay.CurrentCharacters)
                {
                    if (c.dataRef.characterId == "TwinDemonTwin_WING")
                    {
                        twinHellspawnInPlay = true;
                    }
                }
                foreach (Character c in Gameplay.CurrentCharacters)
                {
                    if (c == pickedChar)
                    {
                        if (allDatas.Length == 0)
                        {
                            var loadedCharList = Resources.FindObjectsOfTypeAll(Il2CppType.Of<CharacterData>());
                            if (loadedCharList != null)
                            {
                                allDatas = new CharacterData[loadedCharList.Length];
                                for (int i = 0; i < loadedCharList.Length; i++)
                                {
                                    allDatas[i] = loadedCharList[i]!.Cast<CharacterData>();
                                    c.statuses.AddStatus(ECharacterStatus.AlteredCharacter, charRef);
                                    c.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                                }
                            }
                        }

                        for (int i = 0; i < allDatas.Length; i++)
                        {
                            if (!twinHellspawnInPlay)
                            {
                                if (allDatas[i].characterId == "TwinDemonTwin_WING")
                                {
                                    Gameplay.Instance.AddScriptCharacter(ECharacterType.Demon, allDatas[i]);
                                    if (c.GetRegisterAs().characterId != allDatas[i].characterId)
                                    {
                                        c.Init(allDatas[i]);
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                if (allDatas[i].characterId == "TwinDemonTriplet_WING")
                                {
                                    Gameplay.Instance.AddScriptCharacter(ECharacterType.Demon, allDatas[i]);
                                    if (c.GetRegisterAs().characterId != allDatas[i].characterId)
                                    {
                                        c.Init(allDatas[i]);
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }
    }
    public w_TwinDemon() : base(ClassInjector.DerivedConstructorPointer<w_TwinDemon>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_TwinDemon(System.IntPtr ptr) : base(ptr)
    {

    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        CharacterData bluff = Characters.Instance.GetRandomUniqueVillagerBluff();
        charRef.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
        Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);

        return bluff;
    }
}


