﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using static MelonLoader.Modules.MelonModule;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Pirate : Role
{
    public override Il2CppSystem.Collections.Generic.List<SpecialRule> GetRules()
    {
        Il2CppSystem.Collections.Generic.List<SpecialRule> sr = new Il2CppSystem.Collections.Generic.List<SpecialRule>();
        sr.Add(new NightModeRule(4));
        return sr;
    }
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("Ready when you are.", null);
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        return new ActedInfo("Ready when you are.", null);
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Night)
        {
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
            Characters charInst = Characters.Instance;
            foreach (Character character in characters)
            {
                newList.Add(character);
            }
            newList.Remove(charRef);
            newList = Characters.Instance.FilterAliveCharacters(newList);
            newList = Characters.Instance.FilterAlignmentCharacters(newList, EAlignment.Good);
            newList = Characters.Instance.FilterCharacterMissingStatus(newList, ECharacterStatus.Corrupted);
            newList = Characters.Instance.FilterHiddenCharacters(newList);
            if (newList.Count > 0)
            {
                Character random = newList[UnityEngine.Random.RandomRangeInt(0, newList.Count)];
                selection.Add(random);
                Health health = PlayerController.PlayerInfo.health;
                health.Damage(1);
                random.onReveal.Invoke();
                if (!random.dataRef.picking)
                {
                    random.Act(ETriggerPhase.Day);
                }
                else
                {
                    random.uses = 1;
                    random.pickable.SetActive(true);
                }
                random.KillByDemon(charRef);
                ActedInfo prevInfo = charRef.GetCurrentActedInfo();
                string prevInfoString = prevInfo.desc;
                string line = "Info";
                if (!(prevInfoString == ""))
                {
                    line = string.Format("{1}\nI attacked #{0}", random.id, prevInfoString);
                }
                else
                {
                    line = string.Format("I attacked #{0}", random.id);
                }
                onActed?.Invoke(new ActedInfo(line, selection));
            }
            else
            {
                if (!charRef.GetCurrentActedInfo().desc.Contains("bone-dry"))
                {
                    string info = string.Format("{0}\nThis place is bone-dry, no treasure in-sight.", charRef.GetCurrentActedInfo());
                    onActed?.Invoke(new ActedInfo(info, selection));
                }
            }
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Night)
        {
            Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
            string info = "This place is bone-dry, no treasure in-sight.";
            onActed?.Invoke(new ActedInfo(info, selection));
        }
    }
    public override string Description
    {
        get
        {
            return "Kills & reveals at night.";
        }
    }
    public w_Pirate() : base(ClassInjector.DerivedConstructorPointer<w_Pirate>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Pirate(IntPtr ptr) : base(ptr)
    {
    }
}


