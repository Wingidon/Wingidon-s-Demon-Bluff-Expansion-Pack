﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using static MelonLoader.MelonLogger;
using static MelonLoader.Modules.MelonModule;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Lamb : Role
{
    public override ActedInfo GetInfo(Character charRef)
    {
        string info = "";
        Il2CppSystem.Collections.Generic.List<Character> chars = null;
        Il2CppSystem.Collections.Generic.List<Character> allOutcasts = Gameplay.CurrentCharacters;
        if (allOutcasts.Contains(charRef))
        {
            allOutcasts.Remove(charRef);
        }
        allOutcasts = Characters.Instance.FilterCharacterType(allOutcasts, ECharacterType.Outcast);
        if (allOutcasts.Count > 0)
        {
            Character pickedOutcast = allOutcasts[UnityEngine.Random.Range(0, allOutcasts.Count)];

            int closestOutcast = GetDistanceToCharacter(charRef, pickedOutcast);
            chars = Characters.Instance.GetCharactersAtRange(closestOutcast, charRef);

            info = ConjourInfo(pickedOutcast.GetRegisterAs().name, closestOutcast);
        }
        else
        {
            info = "There are no Outcasts";
        };
        ActedInfo newInfo = new ActedInfo(info,chars);
        return newInfo;
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        string info = "";
        Il2CppSystem.Collections.Generic.List<Character> chars = null;
        Il2CppSystem.Collections.Generic.List<Character> allChars = Gameplay.CurrentCharacters;
        Il2CppSystem.Collections.Generic.List<Character> allOutcasts = Gameplay.CurrentCharacters;
        Il2CppSystem.Collections.Generic.List<Character> allValidTargets = Gameplay.CurrentCharacters;
        Il2CppSystem.Collections.Generic.List<Character> outcastsWithSameName = null;
        if (allOutcasts.Contains(charRef))
        {
            allOutcasts.Remove(charRef);
        }
        allOutcasts = Characters.Instance.FilterCharacterType(allOutcasts, ECharacterType.Outcast);
        if (allOutcasts.Count > 0)
        {
            Character pickedOutcast = allOutcasts[UnityEngine.Random.Range(0, allOutcasts.Count)];
            string pickedOutcastName = pickedOutcast.GetRegisterAs().name;
            allValidTargets.Remove(pickedOutcast);
            Character trueTarget = allValidTargets[UnityEngine.Random.Range(0, allValidTargets.Count)];

            int Distance = GetDistanceToCharacter(charRef, trueTarget);
            chars = Characters.Instance.GetCharactersAtRange(Distance, charRef);

            info = ConjourInfo(pickedOutcastName, Distance);
        }
        else
        {
            info = "There are no Outcasts";
        }
        ;
        ActedInfo newInfo = new ActedInfo(info, chars);
        return newInfo;
    }
    public override string Description
    {
        get
        {
            return "Learn the distance from me to a particular Outcast.";
        }
    }
    public static int RoundValToInt(decimal val)
    {
        return (int)Math.Round(val);
    }
    public string ConjourInfo(string charName, int steps)
    {
        //if (steps > 20)
        //    return $"There are no Outcasts.";
        if (steps == 0)
            return $"I am 1 card away from the {charName}";
        else
            return $"I am {steps + 1} cards away from the {charName}";
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetInfo(charRef));
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetBluffInfo(charRef));
        }
    }
    public int GetDistanceToCharacter(Character charRef, Character targetChar)
    {
        Il2CppSystem.Collections.Generic.List<Character> clockwise = new Il2CppSystem.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> counterclockwise = new Il2CppSystem.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> relevantCharacters = Gameplay.CurrentCharacters;
        int clockwiseNumber = 0;
        int counterClockwiseNumber = 0;
        int targetListNum = 0;
        while (relevantCharacters[targetListNum] != charRef)
        {
            UnityEngine.Debug.Log(string.Format("At #{0}, incrementing", relevantCharacters[targetListNum].id));
            targetListNum++;
        }
        UnityEngine.Debug.Log(string.Format("Found starting character at #{0}", relevantCharacters[targetListNum].id));
        while (relevantCharacters[targetListNum] != targetChar)
        {
            clockwiseNumber++;
            UnityEngine.Debug.Log(string.Format("At {0}, incrementing. New number is {1}", relevantCharacters[targetListNum].id, clockwiseNumber));
            targetListNum++;
            if (targetListNum > relevantCharacters.Count)
            {
                targetListNum = 0;
                UnityEngine.Debug.Log(string.Format("Looping back around to {0}", relevantCharacters[targetListNum].id));
            }
        }
        UnityEngine.Debug.Log(string.Format("Found target at {0}, final number is {1}", relevantCharacters[targetListNum].id, clockwiseNumber));
        while (relevantCharacters[targetListNum] != charRef)
        {
            counterClockwiseNumber++;
            UnityEngine.Debug.Log(string.Format("At {0}, incrementing. New number is {1}", relevantCharacters[targetListNum].id, counterClockwiseNumber));
            targetListNum++;
            if (targetListNum > relevantCharacters.Count)
            {
                targetListNum = 0;
                UnityEngine.Debug.Log(string.Format("Looping back around to {0}", relevantCharacters[targetListNum].id));
            }
        }
        UnityEngine.Debug.Log(string.Format("Found target at {0}, final number is {1}", relevantCharacters[targetListNum].id, counterClockwiseNumber));
        if (clockwiseNumber < counterClockwiseNumber)
        {
            UnityEngine.Debug.Log(string.Format("Returning {0}", clockwiseNumber));
            return clockwiseNumber;
        }
        else
        {
            UnityEngine.Debug.Log(string.Format("Returning {0}", counterClockwiseNumber));
            return counterClockwiseNumber;
        }
        return clockwiseNumber;
    }
    public w_Lamb() : base(ClassInjector.DerivedConstructorPointer<w_Lamb>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Lamb(IntPtr ptr) : base(ptr)
    {
    }
}


