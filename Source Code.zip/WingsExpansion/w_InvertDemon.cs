﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using static Il2CppSystem.Globalization.CultureInfo;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_InvertDemon : Demon
{
    public CharacterData[] allDatas = Il2CppSystem.Array.Empty<CharacterData>();
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            foreach (Character character in Gameplay.CurrentCharacters)
            {
                if (character.GetRegisterAs().type == ECharacterType.Villager && character.GetAlignment() == EAlignment.Good)
                {
                    character.statuses.AddStatus(ECharacterStatus.Corrupted, charRef);
                    character.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                }
                if (character.GetAlignment() == EAlignment.Evil)
                {
                    character.statuses.AddStatus(ECharacterStatus.HealthyBluff, charRef);
                    character.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                }
            }
        }
    }
    public w_InvertDemon() : base(ClassInjector.DerivedConstructorPointer<w_InvertDemon>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_InvertDemon(System.IntPtr ptr) : base(ptr)
    {

    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        CharacterData bluff = Characters.Instance.GetRandomUniqueVillagerBluff();
        charRef.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
        Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);

        return bluff;
    }
}


