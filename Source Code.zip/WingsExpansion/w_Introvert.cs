﻿using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using Il2Cpp;
using System.Diagnostics.Metrics;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Introvert : Role
{
    public override ActedInfo GetInfo(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        foreach (Character c in characters)
        {
            if (GetDistanceBetweenCharacters(charRef, c, characters.Count) < 3 && c != charRef) // Make sure we're not adding ourselves to the list!
            {
                newList.Add(c);
                selection.Add(c);
                UnityEngine.Debug.Log(string.Format("Adding character at #{0}", c.id));
            }
        }
        Character char1 = new Character();
        Character char2 = new Character();
        UnityEngine.Debug.Log(string.Format("Found {0} valid characters", newList.Count));
        char1 = newList[UnityEngine.Random.Range(0, newList.Count)];
        UnityEngine.Debug.Log(string.Format("Using {1} at #{0}", char1.id, char1.GetRegisterAs().name));
        newList.Remove(char1);
        char2 = newList[UnityEngine.Random.Range(0, newList.Count)];
        UnityEngine.Debug.Log(string.Format("Using {1} at #{0}", char2.id, char2.GetRegisterAs().name));
        string line = ConjourInfo(char1.GetRegisterAs().name, char2.GetRegisterAs().name);
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override ActedInfo GetBluffInfo(Character charRef) // Backs up a Disguised character's Disguise (check), or accuses a nearby character of being a random Evil in the Deck (check) or a random character that's Disguised somewhere (check).
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<CharacterData> newList2 = new Il2CppSystem.Collections.Generic.List<CharacterData>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        newList2 = Gameplay.Instance.GetScriptCharacters();
        newList2 = Characters.Instance.FilterAlignmentCharacters(newList2, EAlignment.Evil); // This gets Evil characters in the Deck.
        string name1 = "";
        string name2 = "";
        foreach (Character c in characters)
        {
            if (GetDistanceBetweenCharacters(charRef, c, characters.Count) < 3)
            {
                selection.Add(c);
            }
        }
        if (UnityEngine.Random.Range(0,2) == 0) // Whether to include a correct result or not.
        {
            foreach (Character c in characters)
            {
                if (GetDistanceBetweenCharacters(charRef, c, characters.Count) < 3)
                {
                    newList.Add(c);
                }
            }
            name1 = newList[UnityEngine.Random.Range(0, newList.Count)].GetRegisterAs().name;
        }
        foreach (Character c in characters) // This loop adds all nearby character Disguises to the list, as well as all Disguised characters.
        {
            if (c.bluff && !newList2.Contains(c.bluff) && GetDistanceBetweenCharacters(charRef, c, characters.Count) < 3) // If they're Disguised, and the list doesn't contain their Disguise already, and the distance is less than 3, add the bluff.
            {
                newList2.Add(c.bluff);
            }
            if (c.bluff) // If they're Disguised, add them.
            {
                newList2.Add(c.GetRegisterAs());
            }
        }
        foreach (Character c in characters) // This loop removes all "correct" info from the list.
        {
            if (GetDistanceBetweenCharacters(charRef, c, characters.Count) < 3 && newList2.Contains(c.GetRegisterAs())) // If they're close to the charRef and the list includes them, remove them
            {
                newList2.Remove(c.GetRegisterAs());
            }
        }
        int counter = UnityEngine.Random.Range(0, newList2.Count);
        name2 = newList2[counter].name; // Sets the first character.
        newList2.Remove(newList2[counter]); // Makes sure the first character doesn't show up twice.
        if (name1 == "") // If the first name is blank...
        {
            name1 = newList2[UnityEngine.Random.Range(0, newList2.Count)].name; // Sets the second character.
        }
        string line = ConjourInfo(name1, name2);
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override string Description
    {
        get
        {
            return "Learn 2 characters within 2 cards of me.";
        }
    }
    public int GetDistanceBetweenCharacters(Character char1, Character char2, int totalCharCount)
    {
        int tempDist = char1.id - char2.id;
        if (tempDist < 0)
        {
            tempDist = tempDist + totalCharCount;
        }
        int tempDist2 = char2.id - char1.id;
        if (tempDist2 < 0)
        {
            tempDist2 = tempDist2 + totalCharCount;
        }
        if (tempDist > tempDist2)
        {
            return tempDist2;
        }
        return tempDist;
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            this.onActed.Invoke(this.GetInfo(charRef));
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            this.onActed.Invoke(this.GetBluffInfo(charRef));
        }
    }
    public string ConjourInfo(string charName1, string charName2)
    {
       return string.Format("The {0} and the {1} sit within 2 cards of me", charName1, charName2);
    }
    public w_Introvert() : base(ClassInjector.DerivedConstructorPointer<w_Introvert>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Introvert(IntPtr ptr) : base(ptr)
    {
    }
}


