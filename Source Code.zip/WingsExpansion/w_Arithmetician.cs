﻿using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using Il2Cpp;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Arithmetician : Role
{
    public override ActedInfo GetInfo(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        System.Collections.Generic.List<Character> newList = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList2 = new System.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        Characters charInst = Characters.Instance;
        foreach (Character character in characters)
        {
            if (character.GetAlignment() == EAlignment.Evil)
            {
                newList.Add(character);
            }
        }
        int myMathNumber = 0;
        foreach (Character character in newList)
        {
            myMathNumber += character.id;
        }
        string line = string.Format("The sum of all Evil is: {0}", myMathNumber);
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        System.Collections.Generic.List<Character> newList = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList2 = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList3 = new System.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        Characters charInst = Characters.Instance;
        foreach (Character character in characters)
        {
            if (character.GetAlignment() == EAlignment.Evil)
            {
                newList.Add(character);
            }
        }
        int myMathNumber = 0;
        foreach (Character character in newList)
        {
            myMathNumber += character.id;
        }
        int myCorrectMathNumber = myMathNumber;

        int evilCount = newList.Count;
        while (myCorrectMathNumber == myMathNumber)
        {
            newList.Clear();
            newList2.Clear();
            newList3.Clear();
            foreach (Character character in characters)
            {
                newList3.Add(character);
                if (character.GetAlignment() == EAlignment.Evil)
                {
                    newList.Add(character);
                }
                else
                {
                    newList2.Add(character);
                }
            }
            myMathNumber = 0;
            Character random = newList2[UnityEngine.Random.RandomRangeInt(0, newList2.Count)];
            newList3.Remove(random);
            for (int i = 0; i < evilCount - 1; i++)
            {
                random = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
                myMathNumber += random.id;
                newList3.Remove(random);

            }
        }
        string line = "Yeah";
        line = string.Format("The sum of all Evil is: {0}", myMathNumber);
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override string Description
    {
        get
        {
            return "Learn the sum of all Evils.";
        }
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetInfo(charRef));
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetBluffInfo(charRef));
        }
    }
    public w_Arithmetician() : base(ClassInjector.DerivedConstructorPointer<w_Arithmetician>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Arithmetician(IntPtr ptr) : base(ptr)
    {
    }
}


