﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using static Il2CppSystem.Globalization.CultureInfo;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Undying : Minion
{
    public CharacterData[] allDatas = Il2CppSystem.Array.Empty<CharacterData>();
    public Il2CppSystem.Collections.Generic.List<Il2Cpp.CharacterData> scriptCharacters = Gameplay.Instance.GetScriptCharacters();
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        int diceRoll = Calculator.RollDice(100);
        if (diceRoll < 51)
        {
            if (trigger == ETriggerPhase.Start)
            {
                for (int j = 0; j < allDatas.Length; j++)
                {
                    if (allDatas[j].characterId == "Acolyte_WING")
                    {
                        Debug.Log("Found Acolyte file.");
                        Debug.Log("Adding Acolyte to Deck.");
                        Gameplay.Instance.AddScriptCharacterIfAble(ECharacterType.Minion, allDatas[j]);
                    }
                }
                Il2CppSystem.Collections.Generic.List<Character> chars = new Il2CppSystem.Collections.Generic.List<Character>(Gameplay.CurrentCharacters.Pointer);
                Character pickedChar = new Character();
                chars = Characters.Instance.FilterCharacterType(chars, ECharacterType.Villager);
                chars = Characters.Instance.FilterAlignmentCharacters(chars, EAlignment.Good);
                if (chars.Count > 0)
                {
                    pickedChar = chars[UnityEngine.Random.Range(0, chars.Count)];
                    foreach (Character c in Gameplay.CurrentCharacters)
                    {
                        if (c == pickedChar)
                        {
                            if (allDatas.Length == 0)
                            {
                                var loadedCharList = Resources.FindObjectsOfTypeAll(Il2CppType.Of<CharacterData>());
                                if (loadedCharList != null)
                                {
                                    allDatas = new CharacterData[loadedCharList.Length];
                                    for (int j = 0; j < loadedCharList.Length; j++)
                                    {
                                        allDatas[j] = loadedCharList[j]!.Cast<CharacterData>();
                                        c.statuses.AddStatus(ECharacterStatus.AlteredCharacter, charRef);
                                        c.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                                    }
                                }
                            }

                            for (int j = 0; j < allDatas.Length; j++)
                            {
                                if (allDatas[j].characterId == "Acolyte_WING")
                                {
                                    if (c.GetRegisterAs().characterId != allDatas[j].characterId)
                                    {
                                        c.Init(allDatas[j]);
                                        c.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetBluffInfo(charRef));
        }
    }
    public w_Undying() : base(ClassInjector.DerivedConstructorPointer<w_Undying>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Undying(System.IntPtr ptr) : base(ptr)
    {

    }
    public override ActedInfo GetInfo(Character charRef)
    {
        List<string> myTaunts = new List<string>();
        myTaunts.Add("Nice try!");
        myTaunts.Add("Not going down that easily!");
        myTaunts.Add("Try that on for size!");
        myTaunts.Add("Hah, as if!");
        myTaunts.Add("Wanna try that again?");
        myTaunts.Add("Hah, fool!");
        myTaunts.Add("Foolish!");
        myTaunts.Add("You know I can fend off the Executioner, right?");
        myTaunts.Add("You can't kill me!");
        myTaunts.Add("Bring it on!");
        myTaunts.Add("Hahahah!");
        myTaunts.Add("Heh...");
        string myChosenTaunt = myTaunts[UnityEngine.Random.RandomRangeInt(0, myTaunts.Count)];
        ActedInfo actedInfo = new ActedInfo(myChosenTaunt, null);
        return actedInfo;
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        List<string> myTaunts = new List<string>();
        myTaunts.Add("Bring it!");
        myTaunts.Add("Try me!");
        myTaunts.Add("Want some? Get some!");
        myTaunts.Add("Think you can beat me? Come and get it then!");
        myTaunts.Add("Come get some!");
        myTaunts.Add("Go on, draw your dagger, let's duel!");
        myTaunts.Add("You call that a knife?");
        myTaunts.Add("Your Executioner's power is nothing to me!");
        myTaunts.Add("Hah, I'd like to see you try!");
        myTaunts.Add("Is that flimsy little knife your weapon of choice?");
        myTaunts.Add("Interesting choice of weapon!");
        myTaunts.Add("I'd like to see you TRY to hurt me with that butterknife!");
        string myChosenTaunt = myTaunts[UnityEngine.Random.RandomRangeInt(0, myTaunts.Count)];
        ActedInfo actedInfo = new ActedInfo(myChosenTaunt, null);
        return actedInfo;
    }
    public override bool CheckIfCanBeKilled(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        bool evilLives = false;
        Il2CppSystem.Collections.Generic.List<Character> charactersNotMe = new Il2CppSystem.Collections.Generic.List<Character>();
        foreach (Character character in characters)
        {
            if (!(character.id == charRef.id))
            {
                charactersNotMe.Add(character);
            }
        }
        charactersNotMe = Characters.Instance.FilterAliveCharacters(charactersNotMe);
        foreach (Character character in charactersNotMe)
        {
            if (character.alignment == EAlignment.Evil)
            {
                Debug.Log(string.Format("Evil found at #{0}, setting EvilLives to true", character.id));
                evilLives = true;
            }
        }
        if (evilLives == true)
        {
            Debug.Log("Evil lives, dealing 4 damage...");
            onActed.Invoke(GetInfo(charRef));
            Health health = PlayerController.PlayerInfo.health;
            health.Damage(4);
        }
        else
        {
            charRef.GetCurrentActedInfo().desc = $"Fine, I yield!";
            charRef.ShowActed(charRef.GetCurrentActedInfo());
        }
        Debug.Log(string.Format("Evil lives? {0}", evilLives));
        return !evilLives;
    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        return null;
    }
    }


