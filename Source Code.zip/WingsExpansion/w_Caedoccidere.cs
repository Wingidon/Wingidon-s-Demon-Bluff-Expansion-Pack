﻿using Il2Cpp;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Caedoccidere : Demon
{
    public override Il2CppSystem.Collections.Generic.List<SpecialRule> GetRules()
    {
        Il2CppSystem.Collections.Generic.List<SpecialRule> sr = new Il2CppSystem.Collections.Generic.List<SpecialRule>();
        sr.Add(new NightModeRule(4));
        return sr;
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Night)
        {
            if (charRef.state == ECharacterState.Dead) return;
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
            Characters charInst = Characters.Instance;
            foreach (Character character in characters)
            {
                newList.Add(character);
            }
            newList.Remove(charRef);
            newList = Characters.Instance.FilterAliveCharacters(newList);
            newList = Characters.Instance.FilterRevealedCharacters(newList);
            newList = Characters.Instance.FilterAlignmentCharacters(newList, EAlignment.Good);
            Health health = PlayerController.PlayerInfo.health;
            health.Damage(3);
            if (!(newList.Count == 0))
            {
                Character myTarget = newList[UnityEngine.Random.Range(0, newList.Count)];
                myTarget.statuses.AddStatus(ECharacterStatus.KilledByEvil, charRef);
                myTarget.statuses.AddStatus(CaedoKill.caedoccidereKill, charRef);
                myTarget.KillByDemon(charRef);
                if (myTarget.dataRef.picking)
                {
                    myTarget.uses = 0;
                    myTarget.pickable.SetActive(false);
                }
            }
        }
    }
    public w_Caedoccidere() : base(ClassInjector.DerivedConstructorPointer<w_Caedoccidere>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Caedoccidere(System.IntPtr ptr) : base(ptr)
    {

    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        CharacterData bluff = Characters.Instance.GetRandomUniqueVillagerBluff();
        Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);

        return bluff;
    }
    public static class CaedoKill
    {
        public static ECharacterStatus caedoccidereKill = (ECharacterStatus)132;
        [HarmonyPatch(typeof(Character), nameof(Character.ShowDescription))]
        public static class ChangeKillByDemonText
        {
            public static void Postfix(Character __instance)
            {
                if (__instance.killedByDemon && __instance.statuses.Contains(caedoccidereKill))
                {
                    HintInfo info = new HintInfo();
                    info.text = "Killed by <color=#FF9999>Caedoccidere</color>\nCannot use abilities.";
                    UIEvents.OnShowHint.Invoke(info, __instance.hintPivot);
                }
            }
        }
    }
}


