﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using static Il2CppSystem.Globalization.CultureInfo;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_FogDemon : Demon
{
    public CharacterData[] allDatas = Il2CppSystem.Array.Empty<CharacterData>();
    public Il2CppSystem.Collections.Generic.List<Il2Cpp.CharacterData> scriptCharacters = Gameplay.Instance.GetScriptCharacters();
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            Il2CppSystem.Collections.Generic.List<CharacterData> outcastDatas = new Il2CppSystem.Collections.Generic.List<CharacterData>();
            Il2CppSystem.Collections.Generic.List<CharacterData> minionDatas = new Il2CppSystem.Collections.Generic.List<CharacterData>();
            for (int i = 0; i < allDatas.Length; i++)
            {
                if (allDatas[i].type == ECharacterType.Outcast)
                {
                    outcastDatas.Add(allDatas[i]);
                }
                if (allDatas[i].type == ECharacterType.Minion && allDatas[i].characterId != "Puppet_15989619" && allDatas[i].characterId != "Acolyte_WING")
                {
                    minionDatas.Add(allDatas[i]);
                }
            }
            int outcastCount = UnityEngine.Random.RandomRangeInt(0, 3);
            int minionCount = UnityEngine.Random.RandomRangeInt(1, 4);
            Il2CppSystem.Collections.Generic.List<Character> validTargets = new Il2CppSystem.Collections.Generic.List<Character>();
            foreach (Character c in Gameplay.CurrentCharacters)
            {
                if (c != charRef)
                {
                    validTargets.Add(c);
                }
            }
            for (int i = 0; i < outcastCount; i++)
            {
                if (!(i == 0))
                {
                    Character targetChar = validTargets[UnityEngine.Random.RandomRangeInt(0, validTargets.Count)];
                    CharacterData targetOutcast = outcastDatas[UnityEngine.Random.RandomRangeInt(0, outcastDatas.Count)];
                    validTargets.Remove(targetChar);
                    outcastDatas.Remove(targetOutcast);
                    targetChar.Init(targetOutcast);
                    targetChar.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                    targetChar.statuses.AddStatus(ECharacterStatus.AlteredCharacter, charRef);
                    Gameplay.Instance.AddScriptCharacterIfAble(targetOutcast.type, targetOutcast);
                }
            }
            for (int j = 0; j < minionCount; j++)
            {
                Character targetChar = validTargets[UnityEngine.Random.RandomRangeInt(0, validTargets.Count)];
                CharacterData targetMinion = minionDatas[UnityEngine.Random.RandomRangeInt(0, outcastDatas.Count)];
                targetChar.Init(targetMinion);
                targetChar.statuses.AddStatus(ECharacterStatus.MessedUpByEvil, charRef);
                targetChar.statuses.AddStatus(ECharacterStatus.AlteredCharacter, charRef);
            }
        }
    }
    public w_FogDemon() : base(ClassInjector.DerivedConstructorPointer<w_FogDemon>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_FogDemon(System.IntPtr ptr) : base(ptr)
    {

    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        CharacterData bluff = Characters.Instance.GetRandomUniqueBluff();
        bluff = Characters.Instance.GetRandomUniqueBluff();
        Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);
        return bluff;
    }
    }


