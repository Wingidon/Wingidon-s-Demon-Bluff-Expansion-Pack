﻿using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using Il2Cpp;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Sheriff : Role
{
    public override ActedInfo GetInfo(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        System.Collections.Generic.List<Character> newList = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList2 = new System.Collections.Generic.List<Character>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        Characters charInst = Characters.Instance;
        foreach (Character character in characters)
        {
            bool disguising = false;
            if (character.statuses != null)
            {
                disguising = character.bluff;
            }
            if (!disguising)
            {
                newList.Add(character);
            }
            else
            {
                newList2.Add(character);
            }
        }
        Character random = newList2[UnityEngine.Random.RandomRangeInt(0, newList2.Count)];
        string line = string.Format("My suspect list contains the {0}", random.charBluff);
        foreach (Character character in characters)
        {
            if (character.charBluff == random.charBluff)
            {
                selection.Add(character);
            }
        }
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
        System.Collections.Generic.List<Character> newList = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList2 = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<Character> newList3 = new System.Collections.Generic.List<Character>();
        System.Collections.Generic.List<String> roleNames = new System.Collections.Generic.List<String>();
        Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
        Characters charInst = Characters.Instance;
        foreach (Character character in characters)
        {
            bool disguising = false;
            if (character.statuses != null)
            {
                disguising = character.bluff;
            }
            if (!disguising)
            {
                newList.Add(character);
                newList3.Add(character);
            }
            else
            {
                newList2.Add(character);
                roleNames.Add(character.charBluff.name);
            }
        }
        foreach (Character character in newList)
        {
            if (roleNames.Contains(character.name))
            {
                newList3.Remove(character);
            }
        }
        Character random = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
        string line = string.Format("My suspect list contains the {0}", random.name);
        foreach (Character character in characters)
        {
            if (character.charBluff.name == random.name)
            {
                selection.Add(character);
            }
        }
        ActedInfo actedInfo = new ActedInfo(line, selection);
        return actedInfo;
    }
    public override string Description
    {
        get
        {
            return "1 of 2 characters is Disguised.";
        }
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetInfo(charRef));
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Day)
        {
            onActed.Invoke(GetBluffInfo(charRef));
        }
    }
    public w_Sheriff() : base(ClassInjector.DerivedConstructorPointer<w_Sheriff>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Sheriff(IntPtr ptr) : base(ptr)
    {
    }
}


