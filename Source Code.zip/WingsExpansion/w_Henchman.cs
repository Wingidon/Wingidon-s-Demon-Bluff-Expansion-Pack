﻿using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using System;
using System.ComponentModel.Design;
using UnityEngine;
using HarmonyLib;
using static Il2CppSystem.Collections.SortedList;
using System.Net.NetworkInformation;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Henchman : Role
{
    int executionCount = 0;
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.None)
        {
            tryChangeAlignment(charRef, EAlignment.Good, executionCount);
            executionCount = executionCount + 1;
        }
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
    }
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("Need a hand?", null);
    }
    public w_Henchman() : base(ClassInjector.DerivedConstructorPointer<w_Henchman>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
    }
    public w_Henchman(System.IntPtr ptr) : base(ptr)
    {

    }
    public override CharacterData GetBluffIfAble(Character charRef)
    {
        int diceRoll = Calculator.RollDice(10);
        CharacterData bluff = Characters.Instance.GetRandomUniqueBluff();

        //List<CharacterData> notInPlayCh = Gameplay.Instance.GetScriptCharacters();
        //notInPlayCh = Characters.Instance.FilterAlignmentCharacters(notInPlayCh, EAlignment.Good);
        //notInPlayCh = Characters.Instance.FilterBluffableCharacters(notInPlayCh);
        //return notInPlayCh[UnityEngine.Random.Range(0, notInPlayCh.Count - 1)];

        if (diceRoll < 5)
        {
            // 100% Double Claim
            bluff = Characters.Instance.GetRandomDuplicateBluff();
        }
        else
        {
            // Become a new character
            bluff = Characters.Instance.GetRandomUniqueBluff();
            Gameplay.Instance.AddScriptCharacterIfAble(bluff.type, bluff);
        }
        return bluff;
    }
    public static void tryChangeAlignment(Character charRef, EAlignment alignmentTarget, int executionCounter)
    {
        if (executionCounter == 0)
        {
            charRef.ChangeAlignment(alignmentTarget);
            charRef.RevealBluff();

        }
    }
}

[HarmonyPatch(typeof(Character), nameof(Character.Act))]
public static class CheckExecution
{
    public static void Postfix(Character __instance, ETriggerPhase trigger)
    {
        if (trigger == ETriggerPhase.OnExecuted && __instance.alignment == EAlignment.Good)
        {
            foreach (Character ch in Gameplay.CurrentCharacters)
            {
                if (ch.dataRef.characterId == "Henchman_WING")
                {
                    ch.Act(ETriggerPhase.None);
                }
            }
        }
    }
}


