﻿using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using MelonLoader;
using UnityEngine;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Archivist : Role // Scrapped for now until I have motivation to finish doing this.
{
    Character chRef;
    private Il2CppSystem.Action action1;
    private Il2CppSystem.Action action2;
    private Il2CppSystem.Action action3;
    public override ActedInfo GetInfo(Character charRef)
    {
        return new ActedInfo("", null);
    }
    public override ActedInfo GetBluffInfo(Character charRef)
    {
        return new ActedInfo("", null);
    }
    public override string Description
    {
        get
        {
            return "Learns if a character is a Villager.";
        }
    }
    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger != ETriggerPhase.Day) return;
        chRef = charRef;
        CharacterPicker.Instance.StartPickCharacters(1);
        CharacterPicker.OnCharactersPicked += action1;
        CharacterPicker.OnStopPick += action2;
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger != ETriggerPhase.Day) return;
        chRef = charRef;
        CharacterPicker.Instance.StartPickCharacters(1);
        CharacterPicker.OnCharactersPicked += action3;
        CharacterPicker.OnStopPick += action2;
    }
    private void CharacterPicked()
    {
        CharacterPicker.OnCharactersPicked -= action1;
        CharacterPicker.OnStopPick -= action2;

        Il2CppSystem.Collections.Generic.List<Character> chars = new Il2CppSystem.Collections.Generic.List<Character>();
        chars.Add(CharacterPicker.PickedCharacters[0]);

        string info = $"";
        if (chars[0].GetCharacterData().type == ECharacterType.Villager)
        {
            info = string.Format("#{0} is a Villager.", chars[0].id);
        }
        else
        {
            Il2CppSystem.Collections.Generic.List<string> possibleInfo = new Il2CppSystem.Collections.Generic.List<string>();
            //            possibleInfo.Add(string.Format("#{0} is not a Villager.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a lemon.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a cabbage.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a peanut.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a potato.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be stupid.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be a moron.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be an idiot.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be dumb.", chars[0].id));
            string newString = possibleInfo[UnityEngine.Random.RandomRangeInt(0, possibleInfo.Count)];
            info = newString;
        }

        onActed?.Invoke(new ActedInfo(info, chars));
        Debug.Log($"{info}");
    }
    private void CharacterPickedLiar()
    {
        CharacterPicker.OnCharactersPicked -= action3;
        CharacterPicker.OnStopPick -= action2;

        Il2CppSystem.Collections.Generic.List<Character> chars = new Il2CppSystem.Collections.Generic.List<Character>();
        chars.Add(CharacterPicker.PickedCharacters[0]);

        string info = $"";
        if (chars[0].GetCharacterData().type != ECharacterType.Villager)
        {
            info = string.Format("#{0} is a Villager.", chars[0].id);
        }
        else
        {
            Il2CppSystem.Collections.Generic.List<string> possibleInfo = new Il2CppSystem.Collections.Generic.List<string>();
            //           possibleInfo.Add(string.Format("#{0} is not a Villager.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a lemon.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a cabbage.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a peanut.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} could be a potato.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be stupid.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be a moron.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be an idiot.", chars[0].id));
            possibleInfo.Add(string.Format("#{0} might be dumb.", chars[0].id));
            string newString = possibleInfo[UnityEngine.Random.RandomRangeInt(0, possibleInfo.Count)];
            info = newString;
        }

        onActed?.Invoke(new ActedInfo(info, chars));
        Debug.Log($"{info}");
    }
    private void StopPick()
    {
        CharacterPicker.OnCharactersPicked -= action1;
        CharacterPicker.OnStopPick -= action2;
        CharacterPicker.OnCharactersPicked -= action3;
    }
    public w_Archivist() : base(ClassInjector.DerivedConstructorPointer<w_Archivist>())
    {
        ClassInjector.DerivedConstructorBody((Il2CppObjectBase)this);
        action1 = new System.Action(CharacterPicked);
        action2 = new System.Action(StopPick);
        action3 = new System.Action(CharacterPickedLiar);
    }
    public w_Archivist(System.IntPtr ptr) : base(ptr)
    {
        action1 = new System.Action(CharacterPicked);
        action2 = new System.Action(StopPick);
        action3 = new System.Action(CharacterPickedLiar);
    }
    public void AddRoleToInfoListByID(string id, Il2CppSystem.Collections.Generic.List<CharacterData> list)
    {
        var roles = Resources.FindObjectsOfTypeAll(Il2CppType.Of<CharacterData>());
        foreach (CharacterData character in roles)
        {
            if (character.characterId == id)
            {
                list.Add(character);
            }
        }
    }
    private Il2CppSystem.Collections.Generic.List<CharacterData> rolesInfo = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Yields, interacts with or tampers with info.
    private Il2CppSystem.Collections.Generic.List<CharacterData> rolesCorruption = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with Corruption.
    private Il2CppSystem.Collections.Generic.List<CharacterData> rolesGameStart = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Has a Game Start ability.
    private Il2CppSystem.Collections.Generic.List<CharacterData> rolesActivate = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Has a manually-activated ability.
    private Il2CppSystem.Collections.Generic.List<CharacterData> evilDetect = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Detects, adds, or is Evil.
    private Il2CppSystem.Collections.Generic.List<CharacterData> goodDetect = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Detects or interacts with specifically Good characters of any non-specific type.
    private Il2CppSystem.Collections.Generic.List<CharacterData> relatedVillagers = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with Villagers.
    private Il2CppSystem.Collections.Generic.List<CharacterData> relatedOutcasts = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with Outcasts
    private Il2CppSystem.Collections.Generic.List<CharacterData> relatedDeath = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Dies, kills, or does something on death.
    private Il2CppSystem.Collections.Generic.List<CharacterData> interactsExecution = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with Executions.
    private Il2CppSystem.Collections.Generic.List<CharacterData> takesHealth = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with Health.
    private Il2CppSystem.Collections.Generic.List<CharacterData> usesDeck = new Il2CppSystem.Collections.Generic.List<CharacterData>(); // Interacts with the Deck.

    public void AddRolesToList() // Adds roles to lists
    {
        AddRoleToInfoListByID("Baron_04539999", rolesGameStart);
        AddRoleToInfoListByID("Baron_04539999", relatedVillagers);
        AddRoleToInfoListByID("Baron_04539999", relatedOutcasts);
        AddRoleToInfoListByID("Baron_04539999", usesDeck);
        AddRoleToInfoListByID("Bartender_TAVERN", rolesGameStart);
        AddRoleToInfoListByID("Bartender_TAVERN", rolesCorruption);
        AddRoleToInfoListByID("BeerThrower_TAVERN", rolesCorruption);
        // Splitting these by lines in my file explorer.
        AddRoleToInfoListByID("Acolyte_WING", evilDetect);
        AddRoleToInfoListByID("Alchemist_94446803", rolesInfo);
        AddRoleToInfoListByID("Alchemist_94446803", rolesCorruption);
        AddRoleToInfoListByID("Alchemist_94446803", rolesGameStart);
        AddRoleToInfoListByID("Alchemist_94446803", relatedVillagers);
        AddRoleToInfoListByID("Amnesiac_VP", relatedDeath);
        AddRoleToInfoListByID("Architect_39883285", rolesInfo);
        AddRoleToInfoListByID("Architect_39883285", evilDetect);
        AddRoleToInfoListByID("Archivist_34476114", rolesInfo);
        AddRoleToInfoListByID("Archivist_34476114", goodDetect);
        AddRoleToInfoListByID("Arithmetician_WING", rolesInfo);
        AddRoleToInfoListByID("Arithmetician_WING", evilDetect);
        AddRoleToInfoListByID("Assassin_EP", rolesActivate);
        AddRoleToInfoListByID("Assassin_EP", interactsExecution);
        AddRoleToInfoListByID("Assassin_EP", takesHealth);
        AddRoleToInfoListByID("Atheist_EP", rolesGameStart);
        AddRoleToInfoListByID("Atheist_EP", usesDeck);
        AddRoleToInfoListByID("Athlete_95133291", rolesInfo);
        AddRoleToInfoListByID("Athlete_95133291", rolesCorruption);
        AddRoleToInfoListByID("auditor_rdm", relatedVillagers);
        AddRoleToInfoListByID("auditor_rdm", rolesActivate);
        AddRoleToInfoListByID("auditor_rdm", takesHealth);
        AddRoleToInfoListByID("Baatender_ER", rolesCorruption);
        AddRoleToInfoListByID("Baatender_ER", rolesGameStart);
        AddRoleToInfoListByID("Baatender_ER", relatedOutcasts);
        AddRoleToInfoListByID("Baker_22847064", rolesInfo);
        AddRoleToInfoListByID("Baker_22847064", relatedVillagers);
    }
}

