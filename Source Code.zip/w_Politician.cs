﻿using Il2CppInterop.Runtime.Injection;
using Il2CppInterop.Runtime.InteropTypes;
using MelonLoader;
using System;
using Il2Cpp;

namespace ExpansionPack;

[RegisterTypeInIl2Cpp]
public class w_Politician : Role
{
    public override string Description
    => "Learn random info";

    public override ActedInfo GetInfo(Character charRef)
    {
        ActedInfo newInfo = infoRoles[UnityEngine.Random.Range(0, infoRoles.Count)].GetInfo(charRef);
        return newInfo;
    }

    public override void Act(ETriggerPhase trigger, Character charRef)
    {
        if (trigger == ETriggerPhase.Start)
        {
            charRef.statuses.AddStatus(ECharacterStatus.Corrupted, charRef, charRef);
        }
        if (trigger != ETriggerPhase.Day) return;
        onActed?.Invoke(GetBluffInfo(charRef));
    }
    public override void BluffAct(ETriggerPhase trigger, Character charRef)
    {
        if (trigger != ETriggerPhase.Day) return;
        if (charRef.statuses.statuses.Contains(ECharacterStatus.Corrupted))
        {
            onActed?.Invoke(GetBluffInfo(charRef));
        }
        else
        {
            onActed?.Invoke(GetInfo(charRef));
        }
    }
    public override bool CheckIfCanRemoveStatus(ECharacterStatus status)
    {
        if (status == ECharacterStatus.Corrupted)
            return false;

        return true;
    }

    public override ActedInfo GetBluffInfo(Character charRef)
    {
        Role role = infoRoles[UnityEngine.Random.Range(0, infoRoles.Count)];
        ActedInfo newInfo = role.GetBluffInfo(charRef);
        return newInfo;
    }

    public List<Role> infoRoles = new List<Role>()
    {
        new Empath(),
        new Scout(),
        new Investigator(),
        new BountyHunter(),
        new Lookout(),
        new Knitter(),
        new Tracker(),
        new Shugenja(),
        new Noble(),
        new Bishop(),
        new Archivist(),
        new Acrobat2(),
        new w_Prince(),
    };
}


