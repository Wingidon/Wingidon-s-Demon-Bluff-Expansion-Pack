﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Il2Cpp;
using Il2CppInterop.Runtime.Injection;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;

namespace ExpansionPack
{
    // Token: 0x02000006 RID: 6
    [RegisterTypeInIl2Cpp]
    public class w_Chiromancer : Role
    {
        // Token: 0x0600000B RID: 11 RVA: 0x00002B04 File Offset: 0x00000D04
        public override ActedInfo GetInfo(Character charRef)
        {
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> newList2 = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> newList3 = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
            Characters charInst = Characters.Instance;
            foreach (Character character in characters)
            {
                bool targetEvil = false;
                bool flag = character.statuses != null;
                if (flag)
                {
                    EAlignment targetAlignment = character.GetAlignment();
                    bool flag2 = targetAlignment == EAlignment.Evil;
                    if (flag2)
                    {
                        targetEvil = true;
                    }
                }
                bool flag3 = !targetEvil;
                if (flag3)
                {
                    newList.Add(character);
                }
                else
                {
                    newList2.Add(character);
                }
                newList3.Add(character);
            }
            Character target = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target);
            newList3.Remove(target);
            Character target2 = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target2);
            newList3.Remove(target2);
            Character target3 = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target3);
            newList3.Remove(target3);
            int target1ID = target.id;
            int target2ID = target2.id;
            int target3ID = target3.id;
            bool EvilSelected = false;
            string target1RoleName = w_Chiromancer.GetFalseDreamerInfo(target);
            string target2RoleName = w_Chiromancer.GetFalseDreamerInfo(target2);
            string target3RoleName = w_Chiromancer.GetFalseDreamerInfo(target3);
            bool flag4 = target.alignment == EAlignment.Evil;
            if (flag4)
            {
                EvilSelected = true;
                target1RoleName = w_Chiromancer.GetCorrectDreamerInfo(target);
            }
            else
            {
                bool flag5 = target2.alignment == EAlignment.Evil;
                if (flag5)
                {
                    EvilSelected = true;
                    target2RoleName = w_Chiromancer.GetCorrectDreamerInfo(target2);
                }
                else
                {
                    bool flag6 = target3.alignment == EAlignment.Evil;
                    if (flag6)
                    {
                        EvilSelected = true;
                        target3RoleName = w_Chiromancer.GetCorrectDreamerInfo(target3);
                    }
                }
            }
            bool flag7 = !EvilSelected;
            if (flag7)
            {
                target = newList2[UnityEngine.Random.RandomRangeInt(0, newList2.Count)];
                target1RoleName = w_Chiromancer.GetCorrectDreamerInfo(target);
            }
            for (int i = 0; i < 3; i++)
            {
                bool flag8 = target1ID > target2ID;
                if (flag8)
                {
                    int targetXID = target1ID;
                    string targetXRoleName = target1RoleName;
                    target1ID = target2ID;
                    target1RoleName = target2RoleName;
                    target2ID = targetXID;
                    target2RoleName = targetXRoleName;
                }
                bool flag9 = target2ID > target3ID;
                if (flag9)
                {
                    int targetXID = target2ID;
                    string targetXRoleName = target2RoleName;
                    target2ID = target3ID;
                    target2RoleName = target3RoleName;
                    target3ID = targetXID;
                    target3RoleName = targetXRoleName;
                }
            }
            string line = string.Format("One is true:\n#{0} is the {3}\n#{1} is the {4}\n#{2} is the {5}", new object[]
            {
                target1ID,
                target2ID,
                target3ID,
                target1RoleName,
                target2RoleName,
                target3RoleName
            });
            return new ActedInfo(line, selection);
        }

        // Token: 0x0600000C RID: 12 RVA: 0x00002DE0 File Offset: 0x00000FE0
        public override ActedInfo GetBluffInfo(Character charRef)
        {
            Il2CppSystem.Collections.Generic.List<Character> characters = Gameplay.CurrentCharacters;
            Il2CppSystem.Collections.Generic.List<Character> newList = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> newList2 = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> newList3 = new Il2CppSystem.Collections.Generic.List<Character>();
            Il2CppSystem.Collections.Generic.List<Character> selection = new Il2CppSystem.Collections.Generic.List<Character>();
            Characters charInst = Characters.Instance;
            foreach (Character character in characters)
            {
                bool targetEvil = false;
                bool flag = character.statuses != null;
                if (flag)
                {
                    EAlignment targetAlignment = character.GetAlignment();
                    bool flag2 = targetAlignment == EAlignment.Evil;
                    if (flag2)
                    {
                        targetEvil = true;
                    }
                }
                bool flag3 = !targetEvil;
                if (flag3)
                {
                    newList.Add(character);
                }
                else
                {
                    newList2.Add(character);
                }
                newList3.Add(character);
            }
            Character target = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target);
            newList3.Remove(target);
            Character target2 = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target2);
            newList3.Remove(target2);
            Character target3 = newList3[UnityEngine.Random.RandomRangeInt(0, newList3.Count)];
            selection.Add(target3);
            newList3.Remove(target3);
            int target1ID = target.id;
            int target2ID = target2.id;
            int target3ID = target3.id;
            string target1RoleName = w_Chiromancer.GetFalseDreamerInfo(target);
            string target2RoleName = w_Chiromancer.GetFalseDreamerInfo(target2);
            string target3RoleName = w_Chiromancer.GetFalseDreamerInfo(target3);
            for (int i = 0; i < 3; i++)
            {
                bool flag4 = target1ID > target2ID;
                if (flag4)
                {
                    int targetXID = target1ID;
                    string targetXRoleName = target1RoleName;
                    target1ID = target2ID;
                    target1RoleName = target2RoleName;
                    target2ID = targetXID;
                    target2RoleName = targetXRoleName;
                }
                bool flag5 = target2ID > target3ID;
                if (flag5)
                {
                    int targetXID = target2ID;
                    string targetXRoleName = target2RoleName;
                    target2ID = target3ID;
                    target2RoleName = target3RoleName;
                    target3ID = targetXID;
                    target3RoleName = targetXRoleName;
                }
            }
            string line = string.Format("One is true:\n#{0} is the {3}\n#{1} is the {4}\n#{2} is the {5}", new object[]
            {
                target1ID,
                target2ID,
                target3ID,
                target1RoleName,
                target2RoleName,
                target3RoleName
            });
            return new ActedInfo(line, selection);
        }

        // Token: 0x17000001 RID: 1
        // (get) Token: 0x0600000D RID: 13 RVA: 0x00003024 File Offset: 0x00001224
        public override string Description
        {
            get
            {
                return "1 of 2 characters is Disguised.";
            }
        }

        // Token: 0x0600000E RID: 14 RVA: 0x0000303C File Offset: 0x0000123C
        public override void Act(ETriggerPhase trigger, Character charRef)
        {
            bool flag = trigger == ETriggerPhase.Day;
            if (flag)
            {
                base.onActed.Invoke(this.GetInfo(charRef));
            }
        }

        // Token: 0x0600000F RID: 15 RVA: 0x00003068 File Offset: 0x00001268
        public override void BluffAct(ETriggerPhase trigger, Character charRef)
        {
            bool flag = trigger == ETriggerPhase.Day;
            if (flag)
            {
                base.onActed.Invoke(this.GetBluffInfo(charRef));
            }
        }

        // Token: 0x06000010 RID: 16 RVA: 0x00003094 File Offset: 0x00001294
        public static string GetCorrectDreamerInfo(Character targetChar)
        {
            bool flag = targetChar.dataRef.role is Recluse;
            string role;
            if (flag)
            {
                role = "\nCabbage";
            }
            else
            {
                bool flag2 = targetChar.GetAlignment() == EAlignment.Evil;
                if (flag2)
                {
                    role = (targetChar.GetCharacterData().name ?? "");
                }
                else
                {
                    Il2CppSystem.Collections.Generic.List<string> evilCharacters = new Il2CppSystem.Collections.Generic.List<string>();
                    foreach (CharacterData character in Gameplay.Instance.GetScriptCharacters())
                    {
                        bool flag3 = character.startingAlignment == EAlignment.Evil;
                        if (flag3)
                        {
                            evilCharacters.Add(character.name);
                        }
                    }
                    role = evilCharacters[UnityEngine.Random.Range(0, evilCharacters.Count)];
                }
            }
            return role;
        }

        // Token: 0x06000011 RID: 17 RVA: 0x0000315C File Offset: 0x0000135C
        public static string GetFalseDreamerInfo(Character targetChar)
        {
            Il2CppSystem.Collections.Generic.List<CharacterData> evilCharacters = new Il2CppSystem.Collections.Generic.List<CharacterData>(Gameplay.Instance.GetScriptCharacters().Pointer);
            evilCharacters = Characters.Instance.FilterAlignmentCharacters(evilCharacters, EAlignment.Evil);
            evilCharacters.Remove(targetChar.dataRef);
            bool flag = evilCharacters.Count == 0;
            if (flag)
            {
                evilCharacters = Characters.Instance.FilterAlignmentCharacters(evilCharacters, EAlignment.Evil);
                evilCharacters.Remove(targetChar.dataRef);
            }
            bool flag2 = evilCharacters.Count == 0;
            if (flag2)
            {
                evilCharacters = new Il2CppSystem.Collections.Generic.List<CharacterData>(Gameplay.Instance.GetAllAscensionCharacters().Pointer);
            }
            CharacterData pickedCh = evilCharacters[UnityEngine.Random.Range(0, evilCharacters.Count)];
            return pickedCh.name;
        }

        // Token: 0x06000012 RID: 18 RVA: 0x00003209 File Offset: 0x00001409
        public w_Chiromancer() : base(ClassInjector.DerivedConstructorPointer<w_Chiromancer>())
        {
            ClassInjector.DerivedConstructorBody(this);
        }

        // Token: 0x06000013 RID: 19 RVA: 0x0000321F File Offset: 0x0000141F
        public w_Chiromancer(IntPtr ptr) : base(ptr)
        {
        }
    }
}
